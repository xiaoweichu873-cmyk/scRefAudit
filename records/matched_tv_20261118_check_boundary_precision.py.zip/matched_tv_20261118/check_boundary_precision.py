"""Post-run numerical QA, not a new search method or outcome selection.

Re-solve every scenario containing a top-two class score gap below 1e-5,
at marginal L1 tolerance 1e-10. Preserve all original outputs unchanged.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'; os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import json
import numpy as np
from run_matched_tv import ROOT, CompositionAudit, dump

qa=ROOT/'boundary_precision';qa.mkdir(exist_ok=True)
dump(qa/'plan.json',dict(reason='Observed small primary differences in lung; check whether near-tied argmax labels depend on solver precision',
                       selection='All completed scenarios with at least one top-two class probability gap <1e-5; no outcome-dependent exclusions',
                       initial_tolerance=1e-7,refined_tolerance=1e-10,original_outputs='retained unchanged'))
rows=[]; changed=[]
for f in sorted((ROOT/'results').glob('*/*/*.npz')):
    with np.load(f) as z:
        p=z['probabilities'];top=np.partition(p,-2,axis=2)[:,:,-2:];gap=top[:,:,1]-top[:,:,0]
        selected=np.flatnonzero((gap<1e-5).any(0))
        if not len(selected):continue
        proportions=z['proportions'][selected]; old=p[:,selected];base=z['baseline_probabilities'].argmax(1)
        original_labels=p.argmax(2)
    with np.load(ROOT/'prepared'/f.relative_to(ROOT/'results')) as z:
        audit=CompositionAudit(z['cost'],z['reference_labels'],b=z['b'],epsilon=.05)
    new=audit.run(proportions,order=1,corrector='chord',tol=1e-10)
    labels=new['probabilities'].argmax(2)
    meta=json.loads(f.with_suffix('.json').read_text())
    for i,k in enumerate(selected):
        diff=int(np.sum(labels[:,i]!=old[:,i].argmax(1)))
        rows.append(dict(group=meta['group'],sample=meta['sample'],scenario=int(k),label_changes=diff,
                         max_probability_difference=float(abs(new['probabilities'][:,i]-old[:,i]).max()),
                         residual=float(new['marginal_residual'][i])))
        if diff: changed.append(rows[-1])
    revised_labels=original_labels.copy();revised_labels[:,selected]=labels
    for block in meta['outcomes']:
        i,j=block['start'],block['stop']
        after=int(np.any(revised_labels[:,i:j]!=base[:,None],axis=1).sum())
        before=block['all_query_hits']
        if after!=before:
            changed.append(dict(group=meta['group'],sample=meta['sample'],tv=block['tv'],method=block['method'],
                                changed_query_hit_count_before=before,changed_query_hit_count_after=after))
    dest=qa/meta['group']/f"fold{meta['fold']}"/f.name;dest.parent.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(dest,scenario_indices=selected,refined_probabilities=new['probabilities'],
                        residual=new['marginal_residual'])
dump(qa/'checks.json',rows)
dump(qa/'summary.json',dict(scenarios_recomputed=len(rows),label_changes=sum(r['label_changes'] for r in rows),
                           max_probability_difference=max(r['max_probability_difference'] for r in rows),
                           max_residual=max(r['residual'] for r in rows),changes=changed))
print((qa/'summary.json').read_text())
