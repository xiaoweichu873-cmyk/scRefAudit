# Reproducing the solver comparison and reference expansion

The followup evaluates fixed-geometry composition audits with 3,000 query cells and
1,200, 2,400 or 4,800 distinct public reference cells. Prepared embeddings and cell
identifiers are included. No raw-data download is needed to repeat the benchmark.

`protocol_followup.json` is the original plan. The separate amendment records the
response to the slow default solver pilot, the shared AA2 safeguard, the decision
not to repeat deterministic time-budget failures, and a correction to the checked
upstream conjugate-gradient interface. This is an exploratory benchmark, not an
assertion that the amended protocol preceded every observed result.

## Published comparator source

SSNS is Tang and Qiu, NeurIPS 2024. SPLR is Wang and Qiu, ICML 2025.
The upstream repository is https://github.com/yixuan/regot-python.
The exact commit and per-file hashes are in
`source/regot_followup/provenance.json`; upstream licenses are retained.

The adapter exposes the existing C++ initial-dual option, uses the same full L1
marginal stopping requirement, corrects the gauge-fixed CG wrapper from m to m−1
dimensions and the associated SSNS cached-direction slice, and changes no search
direction formula, sparsification rule or line search. `changes.patch` preserves
the source diff. An independent wrapper supplies the authors' CG option and a
40-iteration native phase followed by the common batched AA2 fallback for unfinished
scenarios. Previously computed potentials may be reused in nearest-scenario order.
CG denotes the selected upstream option; SPLR's internal low-rank operations retain
the upstream direct linear algebra and are not all replaced by conjugate gradients.
The authors' API does not expose cross-call sparse factorizations or quasi-Newton
history, and no additional cross-call implementation was invented for this study.

These comparators are labeled `SSNS_CG_AA2` and `SPLR_CG_AA2`; they are explicitly
safeguarded adaptations. Native iterations, fallback counts, finite-value failures
and final residuals are recorded. Performance is a workflow/software comparison,
not a proof about the fastest mathematically possible version of either algorithm.

## Environment and build

Use a Python 3.12 environment with `requirements-followup.txt`.
The tested adapter used GCC, Eigen headers supplied by the environment, AVX2 and
OpenMP, with numerical threads restricted to one. Supply `EIGEN3_INCLUDE_DIR` as an
absolute directory containing `Eigen/Core`. Compile the bundled patched source:

```bash
cd source/regot_followup
CC=gcc CXX=g++ python setup.py build_ext --inplace
```

Return to the project root and run:

```bash
python test_followup_baselines.py
python test_followup_cg.py
python run_followup.py
python validate_followup.py
python summarize_followup.py
python audit_followup.py
```

The distributed archive contains the completed per-trial records. The runner
resumes those records by default, rather than silently replacing them. To perform
a new timing experiment, first preserve the published results and start a clean
output directory. Do this once on a separate working copy, before the commands
above; the timestamped destination must not already exist:

```python
from pathlib import Path
import datetime, shutil
current = Path('results/followup')
saved = current.with_name('followup_saved_' + datetime.datetime.now().strftime('%Y%m%d_%H%M%S'))
current.rename(saved)
current.mkdir()
for name in ['scale_input_validation.json', 'exact_build_environment.json',
             'environment_packages.txt', 'original_default_pilot.csv']:
    if (saved / name).exists():
        shutil.copy2(saved / name, current / name)
```

The new run regenerates all probability arrays needed by independent validation.
Do not run `validate_followup.py` against an untouched archive and assume that
missing uncompressed probability arrays represent additional successful checks.
Prepared scale inputs are already included; rebuilding them from raw counts is
optional and is a separate data-provenance exercise.

The included Linux CPython 3.12 extension is a convenience for the tested platform.
The recorded build flags target x86-64 Linux with AVX2 and OpenMP. Other platforms,
including Apple Silicon, require a fresh build and appropriate compiler flags;
no timing or adapter-portability validation on those platforms is claimed. The builder script can regenerate the patched
source from a checkout at the pinned upstream commit, but the already patched
source is sufficient for compilation. Do not run another compute-heavy job during
the sequential timing stage. Validation is deliberately run after timing ends.
Independent POT checks use three worker processes by default, with one numerical
thread each. Set `SOPC_VALIDATION_WORKERS=1` for sequential validation. This does
not change reference initialization, tolerances or iteration limits, and these
validation runtimes are not part of the performance comparison.

## Measurements and outcome records

Every method trial uses a fresh child process on one CPU core. Methods follow a
deterministic cyclically shifted order across configurations and repeats. The
original protocol used the word randomized, but the implemented schedule is
cyclic, not random; no randomization claim is made for these records. Audit time includes
factor or solver preparation, prediction, correction, fallback and class readout.
Common preprocessing and base fits are recorded separately. Memory is the sampled
process RSS with a 10 ms polling interval, together with the process high-water
mark and RSS before audit setup. This environment uses different namespace and
procfs PIDs, so the child reports its `/proc/self` PID for memory observation.

The per-audit budget is 180 seconds. After a deterministic failure or timeout, the
two identical planned repeats are marked as not run, never as successful. Finite
speed ratios require completed matched comparisons. A reported peak before timeout
describes that observed attempt, not the memory needed for completion.

`results/followup/timings.csv` contains the amended final grid;
`timing_summary.csv` contains medians, ranges and all outcome counts.
`pot_validation.csv` contains independent checks, and `paired_validation.csv`
compares all scenarios against AA2. `original_default_pilot.csv` retains the default
LDLT attempts. `results/followup_adapter_pre_fix` contains excluded diagnostics from
before the CG dimension correction; these must not be pooled into the final timing
comparison. Original study results remain in their existing directories.

The release audit found four successful worker records with a process high-water
RSS but missing parent sampling fields. Their original results were preserved in
`results/followup_sampling_diagnostics` and the same four trials were rerun without
changing algorithm parameters. New parent sampling fields are stored separately
in `_monitor.json` files and merged by `read_trial`, avoiding reliance on a shared
worker/parent result file. These are instrumentation repairs, not method failures.

The original 1,200 reference cells are nested in each expanded reference set.
All new cells are genuine and sampled without replacement from eligible reference
donors. The query cells and fitted RNA transform stay fixed. Cell geometry and
class proportions still change when real cells are added; this is practical scale
testing, not a pure dimension-only complexity experiment.

The temporary `.cache_followup` folder is regenerated on demand and excluded from
the archive. Complete repeated probability arrays are only needed during local
validation; compact corrected probabilities and numerical check tables are retained
in the distributed archive. The original source checksums and prepared arrays make
all outputs reproducible.
