# Numerical formulation and provenance

These are standard implicit differentiation and modified-Newton identities applied to a repeated-composition workload. They are not presented as new theorems. See references 1–7 in `references.json`.

## Fixed objective and readout

For positive marginals `a`, `b`, a fixed finite cost `C`, and fixed positive entropy `epsilon`, minimize

\[
\langle C,G\rangle+\epsilon\sum_{ij}G_{ij}(\log G_{ij}-1),
\quad G\mathbf1=a,\quad G^T\mathbf1=b.
\]

The positive solution is `G = diag(u) K diag(v)`, with `K = exp(-C/epsilon)`. The entropy scale is absorbed into the log-scalings `f=log(u)`, `g=log(v)` used in the code. They are not the unscaled Kantorovich potentials.

For one-hot reference labels `Y`, `P = diag(a)^(-1) G Y`. If `p0=b0.T @ Y`, define `W[j,k]=b0[j]*Y[j,k]/p0[k]`; then `b(p)=W @ p`. All within-class cell weights remain in their original relative proportions.

The code uses redundant composition directions `D = W - b0[:,None]`. Each column sums to zero. For any simplex displacement `delta` with sum zero, `D @ delta = W @ delta`. Direction `D[:,k]` also corresponds to moving from `p0` toward the pure class vertex `e_k`; finite evaluated compositions remain strictly positive.

## First derivatives

For direction `d_b`, differentiation of the two marginal equations yields

\[
\begin{pmatrix}\mathrm{diag}(a)&G\\G^T&\mathrm{diag}(b)\end{pmatrix}
\begin{pmatrix}f'\\g'\end{pmatrix}
=\begin{pmatrix}0\\d_b\end{pmatrix}.
\]

Eliminate `f'` and impose a gauge with

\[
S=\mathrm{diag}(b)-G^T\mathrm{diag}(a)^{-1}G+bb^T,
\quad g'=S^{-1}d_b,
\quad f'=-\mathrm{diag}(a)^{-1}Gg'.
\]

The optional source-side elimination in `core.py` gives an algebraically equivalent system of the other dimension. The shared-curvature corrector uses the target side. After solving, the implementation shifts the two potentials by opposite constants to impose `a.T @ f' = 0`; this does not change the derivative of the coupling.

## Mixed second derivatives

For two directions r and s, put `z_r[i,j]=f_r[i]+g_r[j]` and similarly for s. The second coupling derivative is

\[
G_{rs,ij}=G_{ij}(f_{rs,i}+g_{rs,j}+z_{r,ij}z_{s,ij}).
\]

Because the marginal path is linear, its second derivative vanishes. Therefore, the same block matrix solves for `(f_rs,g_rs)` with right-hand side `(-R_query,-R_reference)`, where each R is the corresponding marginal sum of `G*z_r*z_s`.

To avoid a large cell-pair-by-direction tensor, compute

\[
R_q=G(g_r\odot g_s)-a\odot f_r\odot f_s,
\]

\[
R_r=G^T(f_r\odot f_s)+g_r\odot d_{b,s}+g_s\odot d_{b,r}
-b\odot g_r\odot g_s.
\]

These follow directly from the first marginal-derivative equations. The target-side Schur right-hand side is `-R_r + G.T @ (R_q/a)`. Only the upper-triangular direction pairs are stored. In the Taylor predictor, diagonal pairs receive weight `0.5*delta_r**2`; off-diagonal pairs receive `delta_r*delta_s`.

## Shared-curvature correction

For arbitrary `g`, let `v=exp(g)`, `u=a/(K@v)`, and `h(g)=v*(K.T@u)`. The query marginal is exact after this normalization. At a current coupling,

\[
J(g)=\mathrm{diag}(h(g))-G(g)^T\mathrm{diag}(a)^{-1}G(g).
\]

Its quadratic form is a sum of row-conditional variances, so it is positive semidefinite with the constant vector as a null direction for a strictly positive kernel. The rank-one term fixes the gauge. At the fitted base point, `h(g0)=b0`, giving the cached S above.

The classical chord step uses `delta_g = S0^(-1) * (b_new-h(g))`. Reusing this factorization avoids building a new full Hessian at every scenario and every iteration. It is a local approximation to Newton's method; large changes can make it slow or ineffective. No global convergence or uniform acceleration theorem is claimed for the implemented heuristic. A backtracking residual test and an explicit finite-iteration fallback are used.

The maximum log update is initially limited to four. Up to 12 halvings test an L1 residual decrease. After 40 chord iterations, or a failed search, remaining scenarios go to the common AA2 corrector. A result is accepted only if its residual is finite and at most the requested tolerance (with a small floating-point comparison allowance). If the fallback fails, the program reports failure instead of returning approximate probabilities as if they were converged.

## Local annotation derivatives

For each reference-class direction k,

\[
\partial_k P=\mathrm{diag}(f_k)P+\mathrm{diag}(a)^{-1}G\,\mathrm{diag}(g_k)Y.
\]

`CompositionAudit.local_sensitivity()` returns this quantity. It is a local derivative, not the finite-scenario corrected output or a probability confidence interval. The implementation verifies it against central finite differences on an independent small problem.

## Cost and interpretation

For a dense n-by-m kernel, building the target Schur factor costs approximately `O(n*m^2 + m^3)`. Batched correction uses kernel matrix products `O(n*m*B)` and cached triangular solves `O(m^2*B)` per chord step, plus backtracking and any fallback. Class readout additionally costs `O(n*m*B*q)` and is included in reported timings. Dense storage is `O(n*m + m^2 + (n+m)*B + n*B*q)`.

These costs explain why reuse can help a batch while setup can penalize small jobs, and why the method is not a solution to full-atlas dense-memory scaling. An observed speedup does not change the underlying statistical assumptions, annotation accuracy or experimental evidence.
