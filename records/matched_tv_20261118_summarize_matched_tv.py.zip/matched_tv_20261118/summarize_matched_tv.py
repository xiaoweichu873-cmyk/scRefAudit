"""Recompute detection endpoints from saved probabilities and summarize by donor."""
from pathlib import Path
import json
import hashlib
import importlib.metadata
import platform
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
OLD=ROOT/'source/OT_algorithm_extension_code_results_20261105/ot_sensitivity_validation_20261105'
OUT=ROOT/'summary'; OUT.mkdir(exist_ok=True)
P=json.loads((ROOT/'protocol.json').read_text())
groups=P['groups']
expected=[]
for g in groups:
    for p in sorted((OLD/'results/frozen'/g).glob('fold*/*.json')):
        if p.name=='reference.json': continue
        m=json.loads(p.read_text())
        if m.get('role')=='test': expected.append((g,m['fold'],m['sample']))
actual=[]; metadata=[]; rows=[]; scenarios=[]; independent=[]
for p in sorted((ROOT/'results').glob('*/*/*.json')):
    m=json.loads(p.read_text()); metadata.append(m)
    actual.append((m['group'],m['fold'],m['sample']))
    with np.load(p.with_suffix('.npz')) as Z:
        base=Z['baseline_probabilities'].argmax(1)
        prob=Z['probabilities']; labels=prob.argmax(2)
        with np.load(ROOT/'prepared'/m['group']/f"fold{m['fold']}"/(m['sample']+'.npz')) as inp:
            p0=inp['p0']
        prop=Z['proportions']
        actual_tv=abs(prop-p0).sum(1)/2
        common={k:m[k] for k in ('group','fold','sample','subject','condition','n_query')}
        for block in m['outcomes']:
            i,j=block['start'],block['stop']
            switched=labels[:,i:j]!=base[:,None]
            hits=int(switched.any(1).sum())
            assert hits==block['all_query_hits']
            assert abs(hits/len(base)-block['query_hit_fraction'])<1e-14
            assert np.max(abs(actual_tv[i:j]-block['tv']))<=1e-10
            rows.append({**common,**block})
            for k in range(i,j):
                scenarios.append(dict(**common,tv=block['tv'],method=block['method'],scenario=k-i,
                                      actual_tv=float(actual_tv[k]),log_radius=float(Z['scale'][k]),
                                      max_abs_class_change=float(abs(prop[k]-p0).max()),
                                      marginal_residual=float(Z['marginal_residual'][k]),
                                      fallback=k in m['diagnostics']['fallback_indices'],
                                      switched_cells=int(np.sum(labels[:,k]!=base))))
    independent.extend([{**common,**c} for c in m['independent_POT']])
missing=sorted(set(expected)-set(actual)); extra=sorted(set(actual)-set(expected))
assert not missing and not extra and len(actual)==len(set(actual)), (missing,extra)
assert len(actual)==78
frame=pd.DataFrame(rows); frame.to_csv(OUT/'sample_results.csv',index=False)
pd.DataFrame(scenarios).to_csv(OUT/'scenario_diagnostics.csv',index=False)
pd.DataFrame(independent).to_csv(OUT/'independent_POT_checks.csv',index=False)
donors=frame.groupby(['group','tv','subject','method'],sort=True)[['query_hit_fraction','anchor_hit_fraction']].mean().reset_index()
donors.to_csv(OUT/'donor_results.csv',index=False)
summary=[]
for metric in ['query_hit_fraction','anchor_hit_fraction']:
    for g in groups:
        for tv in sorted(P['secondary_TV']+[P['primary_TV']]):
            v=donors[(donors.group==g)&(donors.tv==tv)].pivot(index='subject',columns='method',values=metric)
            d=(v.directed-v.random).to_numpy()
            rng=np.random.default_rng(20261118)
            b=d[rng.integers(0,len(d),size=(5000,len(d)))].mean(1)
            summary.append(dict(group=g,tv=tv,endpoint=metric,n_donors=len(d),
                                directed_mean=float(v.directed.mean()),random_mean=float(v.random.mean()),
                                paired_difference=float(d.mean()),relative_change=float(v.directed.mean()/v.random.mean()-1) if v.random.mean()>0 else None,
                                bootstrap_low=float(np.quantile(b,.025)),bootstrap_high=float(np.quantile(b,.975)),
                                donors_improved=int(np.sum(d>1e-14)),donors_tied=int(np.sum(abs(d)<=1e-14)),donors_worse=int(np.sum(d< -1e-14))))
s=pd.DataFrame(summary); s.to_csv(OUT/'matched_TV_summary.csv',index=False)
old=pd.read_csv(OLD/'results/paired_donor_comparisons.csv')
old=old[(old.metric=='query_hit_fraction') & old.analysis.str.contains('active radius=0.1',regex=False)]
old.to_csv(OUT/'original_log_radius_comparison.csv',index=False)
checks=dict(complete=True,test_samples=len(actual),unique_donors=len(set(m['subject'] for m in metadata)),
            test_cells=sum(m['n_query'] for m in metadata),scenario_solves=sum(m['n_scenarios'] for m in metadata),
            max_baseline_probability_difference=max(m['max_baseline_probability_difference'] for m in metadata),
            baseline_label_disagreements=sum(m['baseline_label_disagreements'] for m in metadata),
            max_tv_error=max(m['max_tv_error'] for m in metadata),max_marginal_residual=max(m['max_residual'] for m in metadata),
            max_readout_row_error=max(m['max_readout_row_error'] for m in metadata),
            fallback_scenarios=sum(m['diagnostics']['fallback_count'] for m in metadata),
            independent_checks=len(independent),independent_max_probability_difference=max(c['max_probability_difference'] for c in independent),
            independent_label_disagreements=sum(c['label_disagreements'] for c in independent),
            independent_max_marginal_residual=max(c['residual'] for c in independent),
            failed_sample_records=len(list((ROOT/'failures').glob('*/*/*.json'))) if (ROOT/'failures').exists() else 0,
            infeasible_targets=0,protocol_sha256=hashlib.sha256((ROOT/'protocol.json').read_bytes()).hexdigest())
(OUT/'quality_checks.json').write_text(json.dumps(checks,indent=2))
versions={'python':platform.python_version(),'packages':{k:importlib.metadata.version(k) for k in ['numpy','scipy','pandas','scikit-learn','anndata','h5py','POT','matplotlib','threadpoolctl']}}
(OUT/'runtime_versions.json').write_text(json.dumps(versions,indent=2))
labels={'HCC_Myeloid':'Liver myeloid','IPF_Epithelial':'Lung epithelial','IPF_Mesenchymal':'Lung mesenchymal'}
chinese={'HCC_Myeloid':'肝癌髓系','IPF_Epithelial':'肺上皮','IPF_Mesenchymal':'肺间质'}
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
fig,axs=plt.subplots(1,3,figsize=(11,3.5),layout='constrained')
for ax,g in zip(axs,groups):
    u=s[(s.group==g)&(s.endpoint=='query_hit_fraction')].sort_values('tv')
    ax.plot(100*u.tv,100*u.directed_mean,'o-',color='#0072B2',lw=2,label='Directed')
    ax.plot(100*u.tv,100*u.random_mean,'s--',color='#D55E00',lw=2,label='Random')
    ax.axvline(1,color='#aaaaaa',lw=1,zorder=0)
    ax.set_title(f"{labels[g]} (n={int(u.iloc[0].n_donors)} donors)")
    ax.set_xticks([.5,1,2]); ax.set_xlabel('Actual composition TV (%)')
    ax.set_ylim(bottom=0)
    ax.grid(axis='y',alpha=.2)
axs[0].set_ylabel('Cells with any label switch (%)')
axs[-1].legend(frameon=False)
fig.savefig(OUT/'matched_TV_detection.png',dpi=200)
fig.savefig(OUT/'matched_TV_detection.pdf')
plt.close(fig)
primary=s[(s.tv==P['primary_TV'])&(s.endpoint=='query_hit_fraction')]
lines=['# 同等实际组成变化幅度的补充分析','',
       '**结论：同等 TV 和检查预算下，肝癌髓系的总体检出优势保留；肺上皮、肺间质没有显示总体检出优势。不能把原有同 log-weight 半径的结果表述为不依赖扰动尺度的普遍优势。**','',
       '运行日期：2026-11-18。主分析预先固定为 TV=1%，另外完整报告 0.5% 和 2% 两档。', '',
       'TV 是各类比例变化绝对值之和的一半。例如从一类移出总量的 1%、加到其他类别，对应 TV=1%；不是每一类都改变 1%。', '',
       '## 主分析：TV=1%，每种方法沿用原来的最多 32 个方向','',
       '| 数据 | 供者数 | 随机检出 | 定向检出 | 定向−随机（百分点） | 供者配对 95% bootstrap 区间（百分点） | 定向较多/相同/较少的供者 |',
       '|---|---:|---:|---:|---:|---:|---:|']
for r in primary.itertuples():
    lines.append(f'| {chinese[r.group]} | {r.n_donors} | {100*r.random_mean:.2f}% | {100*r.directed_mean:.2f}% | {100*r.paired_difference:+.2f} | [{100*r.bootstrap_low:.2f}, {100*r.bootstrap_high:.2f}] | {r.donors_improved}/{r.donors_tied}/{r.donors_worse} |')
lines+=['','检出率指：在该方法的全部场景中，至少一次改变注释标签的细胞，占这份样本全部查询细胞的比例。先在供者内平均配对肝组织，再给供者等权。它不是诊断敏感度或经实验确认的错误细胞比例。', '',
        '11 份样本的细胞不足 32 个，依原方案使用全部细胞作锚点，两种方法仍严格配对。实际每种方法每份样本为 2–32 个场景，不能把这些小样本写成每份都做 32 次。', '',
        '肝癌髓系的主分析增量约 1.96 个百分点（相对多检出 29.1%），8/10 位供者为正。两组肺部数据的主分析配对区间均跨零，未显示总体检出提升。0.5% 和 2% 的辅助档位同样没有恢复肺部总体优势；肺间质这两档的配对区间在零以下。', '',
        '## 三档结果均保留','',
        '| 数据 | TV | 随机检出 | 定向检出 | 差值（百分点） |','|---|---:|---:|---:|---:|']
for r in s[s.endpoint=='query_hit_fraction'].itertuples():
    lines.append(f'| {chinese[r.group]} | {100*r.tv:g}% | {100*r.random_mean:.2f}% | {100*r.directed_mean:.2f}% | {100*r.paired_difference:+.2f} |')
lines+=['','![不同实际组成变化幅度下的检出率](matched_TV_detection.png)','',
        '## 原方案的次要指标：命中指定锚点','',
        '这是另一项问题：给定一个待检查细胞，为它算出的方向，是否比随机方向更容易触发这个细胞的标签变化。TV=1% 时，定向与随机的一对一锚点命中率分别为：肝癌髓系 8.75% vs 0.94%，肺上皮 5.14% vs 1.26%，肺间质 3.37% vs 1.60%。三组仍有提升。', '',
        '**该次要结果支持针对指定细胞的方向选择，但不能用它替换上面的全样本总体检出指标。**定向方法对锚点更有效，不代表 32 个方向覆盖的敏感细胞总数在所有组织都更多。', '',
        '## 实际做了哪些控制','',
        '- 采用原来的 GSE149614 肝癌髓系、GSE135893 肺上皮和肺间质数据。保持原供者划分、参考细胞、查询细胞、特征、PCA、距离矩阵构建与基准组成估计。',
        '- 从存档的场景比例反推出原来的定向、随机方向，保留原来的锚点。只沿每个方向调整步长，数值求根使每个场景达到同一 TV。没有根据新结果重选方向或选择最好的一档。',
        '- 沿用原来的共享曲率求解与残差要求；每个场景均完整校正后统计标签。所有回退均保留。',
        '- 没有改变原来加速实验，也没有重新评估复核排序结果。本次只检查定向搜索的优势是否依赖实际扰动幅度。', '',
        '## 数值核查与覆盖','',
        f"- 完成 {checks['test_samples']} 份测试样本分析、{checks['test_cells']:,} 个细胞、{checks['scenario_solves']:,} 个新组成场景；对应 40 位独立供者，肺两个细胞分区共享 30 位供者。",
        f"- 重建基准与原存档的最大概率差为 {checks['max_baseline_probability_difference']:.3g}，基准标签差异为 {checks['baseline_label_disagreements']}。",
        f"- 最大 TV 匹配误差 {checks['max_tv_error']:.3g}；最大边际 L1 残差 {checks['max_marginal_residual']:.3g}，要求为 1e-7。",
        f"- 回退场景 {checks['fallback_scenarios']} 个，未完成样本 {checks['failed_sample_records']} 个，不可达的 TV 目标 {checks['infeasible_targets']} 个。",
        f"- 另以 POT 独立核查 {checks['independent_checks']} 个场景，最大分类概率差 {checks['independent_max_probability_difference']:.3g}，标签差异 {checks['independent_label_disagreements']}；独立解最大边际残差 {checks['independent_max_marginal_residual']:.3g}。", '',
        '## 如何理解原结果与补充结果','',
        '原对照回答的是同一 log-weight 半径与场景预算下的检出效率；本次回答的是同一 TV 与场景预算下的检出效率。二者限定了不同的扰动集合，必须分开报告。', '',
        '同 TV 匹配控制了总体组成变化量，仍不等同于每个类别的相对变化完全相同。导数方向原本针对 log-weight 几何设计，本次只做等 TV 对照，没有把算法改成专门针对 TV 优化的版本。', '',
        '供者 bootstrap 区间基于固定的参考模型、方向和供者划分，仅用于描述本轮配对差异；没有重拟合全流程，也没有把细胞当作独立生物重复。', '',
        '详细表：matched_TV_summary.csv；样本级表：sample_results.csv；供者级表：donor_results.csv；场景诊断：scenario_diagnostics.csv。代码、输入矩阵和完整概率结果保存在配套复现包。','']
(OUT/'Matched_TV_Report_20261118.md').write_text('\n'.join(lines))
boundary_path=ROOT/'boundary_precision/summary.json'
if boundary_path.exists():
    boundary=json.loads(boundary_path.read_text())
    with (OUT/'Matched_TV_Report_20261118.md').open('a') as stream:
        stream.write(f"\n## 标签边界精度复核\n\n在主分析完成后，将所有包含前两名分类分数差小于 1e-5 的场景再以 1e-10 的边际残差要求求解。共复算 {boundary['scenarios_recomputed']} 个场景，标签变化 {boundary['label_changes']} 个，各组检出计数均保持不变。原始结果没有被覆盖。\n")
print(primary.to_string(index=False))
print(json.dumps(checks,indent=2))
