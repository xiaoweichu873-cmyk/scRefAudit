"""Supplemental matched-TV experiment, reusing frozen tissue test inputs.

Run from this directory with venv/bin/python run_matched_tv.py --workers 3.
No original archive is modified. Completed sample checkpoints are reused.
"""
import os
for variable in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[variable] = '1'
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time
import traceback
from concurrent.futures import ProcessPoolExecutor, as_completed

import numpy as np
import pandas as pd
import anndata as ad
from scipy.optimize import brentq
from scipy.spatial.distance import cdist
from scipy.special import softmax
from sklearn.decomposition import PCA
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parent
OLD = ROOT/'source/OT_algorithm_extension_code_results_20261105/ot_sensitivity_validation_20261105'
FROZEN = OLD/'results/frozen'
sys.path.insert(0, str(OLD/'previous/source'))
from sopc_ot import CompositionAudit
spec = importlib.util.spec_from_file_location('original_validation', OLD/'scripts/02_validation.py')
original = importlib.util.module_from_spec(spec)
spec.loader.exec_module(original)
CFG = original.CFG
PROTOCOL = json.loads((ROOT/'protocol.json').read_text())
PROTOCOL_HASH = hashlib.sha256((ROOT/'protocol.json').read_bytes()).hexdigest()
LEVELS = [PROTOCOL['primary_TV']] + PROTOCOL['secondary_TV']
OUT = ROOT/'results'


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name+'.tmp')
    tmp.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False))
    tmp.replace(path)


def matched_proportion(p0, direction, target):
    def at(alpha):
        return softmax(np.log(p0) + alpha*direction)
    def tv(alpha):
        return float(np.abs(at(alpha)-p0).sum()/2)
    upper = .1
    for _ in range(40):
        if tv(upper) >= target:
            break
        upper *= 2
    else:
        raise ValueError(f'TV target {target} unreachable along original direction')
    alpha = brentq(lambda x: tv(x)-target, 0., upper, xtol=1e-14, rtol=1e-14)
    p = at(alpha)
    actual = float(np.abs(p-p0).sum()/2)
    if abs(actual-target)>1e-10 or not np.all(p>0):
        raise ValueError('Invalid matched-TV composition')
    return p, alpha, actual


def independent_checks(audit, C, proportions, probabilities, offsets):
    import ot
    checks = []
    for tv, method, index in offsets:
        bb = audit.W@proportions[index]
        plan = ot.sinkhorn(audit.a, bb, C, CFG['epsilon'], method='sinkhorn',
                          numItermax=100000, stopThr=1e-13, warn=True)
        residual = max(float(abs(plan.sum(0)-bb).sum()), float(abs(plan.sum(1)-audit.a).sum()))
        P = plan@audit.Y/audit.a[:,None]
        diff = float(np.max(abs(P-probabilities[:,index])))
        disagreements = int(np.sum(P.argmax(1)!=probabilities[:,index].argmax(1)))
        checks.append(dict(tv=tv, method=method, scenario=index, residual=residual,
                           max_probability_difference=diff, label_disagreements=disagreements))
        if residual>1e-9 or diff>1e-4:
            raise RuntimeError(f'Independent solution failed numerical check: {checks[-1]}')
    return checks


def run_prepared(path, check=False):
    """Run from a self-contained sample NPZ; supports independent reproduction."""
    t = time.perf_counter()
    with np.load(path) as z:
        Z = {k:z[k] for k in z.files}
    metadata = json.loads(str(Z['metadata']))
    group, fold, sample = (metadata[k] for k in ('group','fold','sample'))
    dest = OUT/group/f'fold{fold}'/sample
    meta_path = dest.with_suffix('.json')
    if meta_path.exists():
        existing = json.loads(meta_path.read_text())
        if existing['protocol_sha256'] != PROTOCOL_HASH:
            raise ValueError('Checkpoint protocol mismatch')
        return existing
    audit = CompositionAudit(Z['cost'], Z['reference_labels'], b=Z['b'], epsilon=CFG['epsilon'])
    baseline_diff = float(abs(audit.base_probabilities-Z['archived_baseline_probabilities']).max())
    base_disagreements = int(np.sum(audit.base_probabilities.argmax(1)!=Z['archived_baseline_probabilities'].argmax(1)))
    if baseline_diff>1e-7 or base_disagreements:
        raise RuntimeError(f'Baseline reconstruction mismatch {baseline_diff}, labels {base_disagreements}')
    nb = len(Z['anchors'])
    methods = ['directed', 'random']
    props, scales, actual_tv, blocks, checks_at = [], [], [], [], []
    for tv in LEVELS:
        for method in methods:
            start = len(props)
            for d in Z[method+'_directions']:
                p, scale, realized = matched_proportion(audit.p0, d, tv)
                props.append(p); scales.append(scale); actual_tv.append(realized)
            blocks.append(dict(tv=tv, method=method, start=start, stop=len(props)))
            checks_at.append((tv, method, start))
    props = np.asarray(props)
    result = audit.run(props, order=1, corrector='chord', tol=CFG['tol'])
    P = result['probabilities']
    # readout rows must also be normalized; marginal residual is recorded per scenario.
    row_error = float(np.max(abs(P.sum(2)-1)))
    if row_error>1e-6:
        raise RuntimeError(f'Readout normalization failed: {row_error}')
    base = audit.base_probabilities.argmax(1)
    labels = P.argmax(2)
    rows = []
    fallback_set = set(result['diagnostics']['fallback_indices'])
    for block in blocks:
        start, stop = block['start'], block['stop']
        switched = labels[:,start:stop]!=base[:,None]
        rows.append(dict(**block, n_scenarios=stop-start,
                         all_query_hits=int(np.any(switched, axis=1).sum()),
                         query_hit_fraction=float(np.any(switched,axis=1).mean()),
                         anchor_hits=int(switched[Z['anchors'],np.arange(nb)].sum()),
                         anchor_hit_fraction=float(switched[Z['anchors'],np.arange(nb)].mean()),
                         fallback_count=sum(i in fallback_set for i in range(start,stop)),
                         max_residual=float(result['marginal_residual'][start:stop].max()),
                         min_actual_tv=float(min(actual_tv[start:stop])),
                         max_actual_tv=float(max(actual_tv[start:stop]))))
    checks = independent_checks(audit,Z['cost'],props,P,checks_at) if check else []
    saved = dict(**metadata, protocol_sha256=PROTOCOL_HASH, n_scenarios=len(props),
                 max_baseline_probability_difference=baseline_diff, baseline_label_disagreements=base_disagreements,
                 baseline_residual=float(audit.base_residual), max_readout_row_error=row_error,
                 max_residual=float(result['marginal_residual'].max()),
                 max_tv_error=float(np.max(abs(np.asarray(actual_tv)-np.repeat(LEVELS,2*nb)))),
                 diagnostics=result['diagnostics'], outcomes=rows, independent_POT=checks,
                 seconds=time.perf_counter()-t)
    dest.parent.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(dest.with_suffix('.npz'), probabilities=P, proportions=props,
                        baseline_probabilities=audit.base_probabilities,
                        marginal_residual=result['marginal_residual'], iterations=result['iterations'],
                        scale=np.asarray(scales), actual_tv=np.asarray(actual_tv),
                        barcodes=Z['barcodes'], classes=audit.classes, anchors=Z['anchors'])
    dump(meta_path,saved)
    print(f"DONE {group} fold{fold} {sample}: {len(props)} solves, max residual {saved['max_residual']:.2e}, {saved['seconds']:.1f}s", flush=True)
    return saved


def one_fold(group, fold, limit=None):
    start=time.perf_counter()
    fd=FROZEN/group/f'fold{fold}'
    samples=[p for p in sorted(fd.glob('*.json')) if p.name!='reference.json' and json.loads(p.read_text()).get('role')=='test']
    if limit is not None:
        samples=samples[:limit]
    if all((OUT/group/f'fold{fold}'/p.name).exists() for p in samples):
        return dict(group=group,fold=fold,complete=len(samples),cached=True)
    plan=json.loads((fd/'reference.json').read_text())
    a=ad.read_h5ad(ROOT/'counts/data'/f'{group}_annotated_counts.h5ad')
    keep=a.obs.passes_QC.to_numpy(copy=True)
    if group.startswith('HCC'):
        keep &= a.obs.condition.isin(['Normal','Tumor']).values
    a=a[keep].copy(); o=a.obs.copy(); o['subject']=o.subject.astype(str); o['label']=o.author_fine.astype(str)
    X=a.X.tocsr()
    ri=o.index.get_indexer(plan['reference_barcodes'])
    hvg=a.var_names.get_indexer(plan['features'])
    assert np.all(ri>=0) and np.all(hvg>=0)
    ro=o.loc[o.subject.isin(plan['reference_donors'])]
    classes=np.asarray(plan['reference_classes'])
    props=pd.crosstab(ro.subject,ro.label,normalize='index').reindex(columns=classes,fill_value=0).mean().values
    rl=o.label.iloc[ri].values
    mat=original.norm(X[ri])[:,hvg].toarray()
    mean=mat.mean(0); sd=np.maximum(mat.std(0),.05)
    pca=PCA(n_components=min(CFG['PCA'],len(ri)-1,len(hvg)-1),svd_solver='randomized',random_state=CFG['seed']+fold)
    rp=pca.fit_transform(np.clip((mat-mean)/sd,-10,10))
    ncomplete=0; failures=[]
    for pos, meta_file in enumerate(samples):
        metadata=json.loads(meta_file.read_text())
        sample=metadata['sample']
        if (OUT/group/f'fold{fold}'/meta_file.name).exists():
            ncomplete+=1; continue
        try:
            print(f'PREPARE {group} fold{fold} {sample}',flush=True)
            with np.load(meta_file.with_suffix('.npz')) as data:
                Z={key:data[key] for key in ('barcodes','classes','baseline_probabilities','active_proportions','active_anchors')}
            qi=o.index.get_indexer(Z['barcodes'])
            assert np.all(qi>=0)
            assert set(o.subject.iloc[qi])<=set(plan['test_donors'])
            assert not set(plan['test_donors']) & set(plan['reference_donors'])
            qmat=original.norm(X[qi])[:,hvg].toarray()
            qp=pca.transform(np.clip((qmat-mean)/sd,-10,10))
            C=cdist(qp,rp,metric='cosine'); scale=float(np.median(C)); C/=scale
            audit,_=original.init_audit(C,rl,props)
            assert np.array_equal(audit.classes,Z['classes'])
            baseline_diff=float(np.max(abs(audit.base_probabilities-Z['baseline_probabilities'])))
            if baseline_diff>1e-7 or np.any(audit.base_probabilities.argmax(1)!=Z['baseline_probabilities'].argmax(1)):
                raise RuntimeError(f'Old baseline mismatch max difference={baseline_diff}')
            # Each of the original first two blocks used radius 0.10. Centering
            # removes the softmax normalizer and recovers its original direction.
            nb=len(Z['active_anchors'])
            ds=np.log(Z['active_proportions'][:2*nb])-np.log(audit.p0)
            ds-=ds.mean(1,keepdims=True); ds/=.1
            norm_error=float(np.max(abs(np.linalg.norm(ds,axis=1)-1)))
            if norm_error>1e-5:
                raise RuntimeError(f'Direction reconstruction norm error={norm_error}')
            ds/=np.linalg.norm(ds,axis=1,keepdims=True)
            reproduction_error=float(np.max(abs(softmax(np.log(audit.p0)+.1*ds,axis=1)-Z['active_proportions'][:2*nb])))
            if reproduction_error>1e-8:
                raise RuntimeError(f'Original scenario reconstruction failed={reproduction_error}')
            info={k:metadata[k] for k in ('group','fold','sample','subject','condition','n_query','n_reference')}
            info.update(source='frozen held-out test', direction_norm_error=norm_error,
                        original_scenario_proportion_error=reproduction_error,
                        distance_scale=scale, original_distance_scale=metadata['distance_scale'],
                        old_metadata_sha256=hashlib.sha256(meta_file.read_bytes()).hexdigest())
            fixture=ROOT/'prepared'/group/f'fold{fold}'/(sample+'.npz')
            fixture.parent.mkdir(parents=True,exist_ok=True)
            np.savez_compressed(fixture,cost=C,reference_labels=rl.astype(str),b=audit.b,p0=audit.p0,
                                directed_directions=ds[:nb],random_directions=ds[nb:],
                                anchors=Z['active_anchors'],barcodes=Z['barcodes'],
                                archived_baseline_probabilities=Z['baseline_probabilities'],
                                metadata=np.asarray(json.dumps(info)))
            run_prepared(fixture,check=(fold==0 and pos==0))
            ncomplete+=1
        except Exception as exc:
            failure=dict(group=group,fold=fold,sample=sample,error=repr(exc),traceback=traceback.format_exc())
            dump(ROOT/'failures'/group/f'fold{fold}'/(sample+'.json'),failure)
            failures.append(failure)
            print('FAILED',group,fold,sample,repr(exc),flush=True)
    return dict(group=group,fold=fold,complete=ncomplete,failures=failures,seconds=time.perf_counter()-start)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--workers',type=int,default=3)
    parser.add_argument('--group',choices=PROTOCOL['groups'])
    parser.add_argument('--fold',type=int)
    parser.add_argument('--limit',type=int)
    parser.add_argument('--prepared',type=Path)
    parser.add_argument('--replay-all',action='store_true',help='Use packaged cost matrices; no count downloads needed')
    args=parser.parse_args()
    OUT.mkdir(exist_ok=True)
    if args.prepared:
        with threadpool_limits(limits=1):
            run_prepared(args.prepared,check=True)
        return
    if args.replay_all:
        files=sorted((ROOT/'prepared').glob('*/*/*.npz'))
        first={}
        for f in files:
            first.setdefault(f.parts[-3],f)
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            jobs={pool.submit(run_prepared,f,f==first[f.parts[-3]]):f for f in files}
            for future in as_completed(jobs):
                future.result()
        return
    groups=[args.group] if args.group else PROTOCOL['groups']
    folds=[args.fold] if args.fold is not None else range(5)
    jobs=[(g,f,args.limit) for g in groups for f in folds]
    statuses=[]
    with threadpool_limits(limits=1):
        if args.workers==1:
            for job in jobs:
                statuses.append(one_fold(*job))
        else:
            with ProcessPoolExecutor(max_workers=args.workers) as pool:
                futs={pool.submit(one_fold,*job):job for job in jobs}
                for fut in as_completed(futs):
                    try:
                        statuses.append(fut.result())
                    except Exception as exc:
                        statuses.append(dict(job=futs[fut],error=repr(exc),traceback=traceback.format_exc()))
                    print('FOLD FINISHED',futs[fut],flush=True)
    dump(ROOT/'run_status.json',statuses)


if __name__=='__main__':
    main()
