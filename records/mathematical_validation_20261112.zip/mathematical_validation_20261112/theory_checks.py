"""Targeted synthetic checks for fixed-curvature OT theory; not biology benchmarks.
Run: python theory_checks.py --source /path/to/software/src --out results
All directions/radii and failed cases are retained. No speed claim is made.
"""
import argparse, csv, json, pathlib, sys
import numpy as np
from scipy.linalg import null_space, eigvalsh, cho_factor, cho_solve
from scipy.special import softmax
from scipy.spatial.distance import cdist
from threadpoolctl import threadpool_limits

def main(source, out):
    sys.path.insert(0, str(source))
    from sopc_ot import CompositionAudit
    out.mkdir(parents=True, exist_ok=True)
    rows=[]; linear=[]; failures=[]
    def putcsv(name, vals):
        if vals:
            with (out/name).open('w',newline='') as f:
                w=csv.DictWriter(f,fieldnames=list(vals[0])); w.writeheader(); w.writerows(vals)
    for seed in [1112,1113,1114]:
      rng=np.random.default_rng(seed)
      n,m,k=48,24,4
      C=cdist(rng.normal(size=(n,4)),rng.normal(size=(m,4)),'sqeuclidean')
      C/=np.median(C); labels=np.arange(m)%k
      directions=rng.normal(size=(3,k));directions-=directions.mean(1,keepdims=True)
      directions/=np.linalg.norm(directions,axis=1,keepdims=True)
      Q=null_space(np.ones((1,m)))
      for eps in [.05,.1,.5]:
        model=CompositionAudit(C,labels,epsilon=eps,base_tol=1e-13)
        a=model.a; g0=np.log(model.v);g0-=g0.mean()
        def ev(g):
            R=softmax(-C/eps+g[None,:],axis=1)
            h=a@R; H=np.diag(h)-R.T@(a[:,None]*R)
            return R,h,H
        R0,h0,H0=ev(g0); A0=Q.T@H0@Q
        S=np.diag(model.b)-(model.G.T/a)@model.G+np.outer(model.b,model.b)
        B=Q.T@np.linalg.solve(S,Q); M=np.linalg.inv(B); M=(M+M.T)/2
        ev0=eigvalsh(A0,M); eta=float(max(abs(ev0-1)))
        def normM(v):return float(np.sqrt(max(0,v@M@v)))
        def fresh(b):
            g=g0.copy()
            for it in range(200):
                R,h,H=ev(g);r=b-h;err=np.abs(r).sum()
                if err<1e-12:return g,R,err,it
                dx=np.linalg.solve(Q.T@H@Q,Q.T@r);dg=Q@dx
                step=min(1.,4/max(np.max(np.abs(dg)),1e-300))
                for bt in range(40):
                    gn=g+step*dg;gn-=gn.mean();rn=ev(gn)[1]
                    if np.abs(rn-b).sum() <= err*(1-1e-4*step):g=gn;break
                    step*=.5
                else:raise RuntimeError('fresh Newton line search failed')
            raise RuntimeError('fresh Newton iteration limit')
        sens=model.local_sensitivity()
        Jp=np.diag(model.p0)-np.outer(model.p0,model.p0)
        for di,d in enumerate(directions):
          grad=np.einsum('nqc,q->nc',sens,Jp@d)
          for radius in [.003,.01,.03,.1,.3,1.,3.]:
            record={'seed':seed,'epsilon':eps,'direction':di,'log_weight_radius':radius}
            try:
                p=softmax(np.log(model.p0)+radius*d);b=model.W@p
                gs,Rs,referr,nit=fresh(b)
                corrected=model.run(p[None,:],order=0,tol=1e-9)
                Pstar=Rs@model.Y;prob=corrected['probabilities'][:,0,:]
                Rpot=float(np.ptp(gs-g0));lo=(1-eta)*np.exp(-Rpot);hi=(1+eta)*np.exp(Rpot)
                qbound=max(1-lo,hi-1)
                qobserved=0.;step_ratio=0.;spectral_violation=0.
                # Sample this line for numerical checking only, not a uniform certificate.
                for t in np.linspace(0,1,9):
                    g=g0+t*(gs-g0);_,h,H=ev(g);A=Q.T@H@Q
                    lam=eigvalsh(A,M);qobserved=max(qobserved,float(max(abs(lam-1))))
                    spectral_violation=max(spectral_violation,lo-float(lam.min()),float(lam.max())-hi)
                    rr=Q.T@(b-h);dn=np.linalg.solve(A,rr);dm=B@rr
                    if normM(dn)>1e-10:
                        step_ratio=max(step_ratio,normM(dm-dn)/normM(dn))
                # Full frozen step from base: endpoint error uses the integrated Hessian.
                e0=Q.T@(g0-gs);x1=Q.T@g0+B@(Q.T@(b-h0))
                contraction_ratio=normM(x1-Q.T@gs)/normM(e0)
                errTaylor=float(np.max(np.abs(Pstar-(model.base_probabilities+radius*grad))))
                linear.append({**record,'maximum_score_linearization_error':errTaylor,
                               'error_over_radius_squared':errTaylor/radius**2})
                rows.append({**record,'status':'completed','reference_residual':referr,
                    'corrected_residual':float(corrected['marginal_residual'].max()),
                    'probability_difference':float(np.max(np.abs(prob-Pstar))),
                    'fallback_count':corrected['diagnostics']['fallback_count'],
                    'baseline_relative_matrix_defect':eta,'potential_oscillation':Rpot,
                    'uniform_path_bound':qbound,'sampled_relative_matrix_error':qobserved,
                    'max_step_relative_error':step_ratio,'one_step_error_ratio':contraction_ratio,
                    'spectral_bound_violation':spectral_violation,'fresh_newton_iterations':nit,
                    'chord_plus_fallback_iterations':int(corrected['iterations'].max())})
            except Exception as ex:
                failures.append({**record,'error':repr(ex)})
    putcsv('synthetic_curvature_checks.csv',rows);putcsv('synthetic_linearization_checks.csv',linear)
    (out/'failed_cases.json').write_text(json.dumps(failures,indent=2))
    slopes=[]
    for seed in [1112,1113,1114]:
      for eps in [.05,.1,.5]:
       for di in range(3):
        r=[x for x in linear if x['seed']==seed and x['epsilon']==eps and x['direction']==di and x['log_weight_radius']<=.03]
        if len(r)==3:
            slopes.append(float(np.polyfit(np.log([x['log_weight_radius'] for x in r]),np.log([x['maximum_score_linearization_error'] for x in r]),1)[0]))
    summary={'scope':'Synthetic mathematical diagnostics; no new biological cohorts and no performance benchmark',
        'planned_cases':189,'completed_cases':len(rows),'failed_cases':len(failures),
        'curvature_bound_violations_above_1e-7':sum(x['spectral_bound_violation']>1e-7 for x in rows),
        'step_bound_violations_above_1e-7':sum(x['max_step_relative_error']>x['uniform_path_bound']+1e-7 for x in rows),
        'one_step_bound_violations_above_1e-7':sum(x['one_step_error_ratio']>x['uniform_path_bound']+1e-7 for x in rows),
        'path_bound_below_one':sum(x['uniform_path_bound']<1 for x in rows),
        'cases_using_fallback':sum(x['fallback_count']>0 for x in rows),
        'max_corrected_residual':max(x['corrected_residual'] for x in rows),
        'max_probability_difference':max(x['probability_difference'] for x in rows),
        'median_local_remainder_order':float(np.median(slopes)),
        'local_remainder_order_range':[min(slopes),max(slopes)],
        'note':'A bound below one along the reference-solution segment is a diagnostic, not an invariant-neighborhood proof for the full safeguarded solver.',
        'python':sys.version,'numpy':np.__version__}
    encoded=json.dumps(summary,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else str(x))
    (out/'summary.json').write_text(encoded);print(encoded)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',type=pathlib.Path,required=True);p.add_argument('--out',type=pathlib.Path,required=True);a=p.parse_args()
    with threadpool_limits(limits=1):main(a.source,a.out)
