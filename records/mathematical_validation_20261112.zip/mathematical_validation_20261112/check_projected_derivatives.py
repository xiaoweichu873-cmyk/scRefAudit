"""Check the manuscript's projected log-composition derivative formula."""
import argparse, json, pathlib, sys
import numpy as np
from scipy.spatial.distance import cdist
from scipy.special import softmax
from scipy.linalg import cho_factor, cho_solve
from threadpoolctl import threadpool_limits

ROOT=pathlib.Path(__file__).resolve().parent
def run(source, archive_root, out):
    sys.path.insert(0,str(source))
    from sopc_ot import CompositionAudit
    from sopc_ot.core import solve
    rec=[]
    for seed in [20261112,20261113,20261114]:
      rng=np.random.default_rng(seed)
      C=cdist(rng.normal(size=(36,4)),rng.normal(size=(24,4)),'sqeuclidean');C/=np.median(C)
      for eps in [.1,.5]:
       for weights in ['uniform','nonuniform']:
        b=np.ones(24)/24 if weights=='uniform' else rng.dirichlet(np.full(24,3.))
        model=CompositionAudit(C,np.arange(24)%4,epsilon=eps,b=b,base_tol=1e-13)
        q=4;Pi=np.eye(q)-np.ones((q,q))/q
        Jp=np.diag(model.p0)-np.outer(model.p0,model.p0)
        H=np.diag(model.b)-(model.G.T/model.a)@model.G
        Jg=cho_solve(cho_factor(H+np.outer(model.b,model.b)),model.W@Jp)
        R=model.G/model.a[:,None]
        J=np.stack([model.Y.T@(np.diag(r)-np.outer(r,r))@Jg for r in R])
        old=np.einsum('nqc,qk->nck',model.local_sensitivity(),Jp)
        identity_error=float(np.max(np.abs(J-old)))
        constant_error=float(np.max(np.abs(J@np.ones(q))))
        fd_error=0.;directions=4;h=1e-4
        for _ in range(directions):
            d=Pi@rng.normal(size=q);d/=np.linalg.norm(d)
            vals=[]
            for sg in [-1,1]:
                pp=softmax(np.log(model.p0)+sg*h*d)
                G,*_=solve(model.K,model.a,model.W@pp,tol=1e-13)
                vals.append(G@model.Y/model.a[:,None])
            fd=(vals[1]-vals[0])/(2*h)
            fd_error=max(fd_error,float(np.max(np.abs(fd-J@d))))
        assert identity_error<1e-9 and constant_error<1e-9 and fd_error<1e-6
        rec.append({'seed':seed,'epsilon':eps,'weights':weights,'chain_rule_identity_error':identity_error,'constant_direction_error':constant_error,'finite_difference_max_error':fd_error,'directions':directions})
    archived=[]
    files=sorted(archive_root.glob('*/baseline.npz'))
    if not files: files=sorted(archive_root.glob('*/directions.npz'))
    if not files: raise FileNotFoundError('No archived baseline.npz or directions.npz files found')
    for p in files:
        v=np.load(p)['direction'];nn=np.linalg.norm(v,axis=1)
        assert np.all(np.isfinite(v))
        assert np.max(np.abs(v.sum(1)))<1e-10 and np.max(np.abs(nn-1))<1e-10
        archived.append({'configuration':p.parent.name,'cells':len(v),'max_absolute_sum':float(np.max(np.abs(v.sum(1)))),'max_norm_error':float(np.max(np.abs(nn-1))),'nonfinite_count':int(np.sum(~np.isfinite(v)))})
    result={'cases':rec,'archived_directions':archived,'summary':{'passed':True,'synthetic_baselines':len(rec),'finite_difference_directions':sum(x['directions'] for x in rec),'chain_rule_identity_error_max':max(x['chain_rule_identity_error'] for x in rec),'finite_difference_error_max':max(x['finite_difference_max_error'] for x in rec),'constant_direction_error_max':max(x['constant_direction_error'] for x in rec),'archived_configurations':len(archived),'archived_directions':sum(x['cells'] for x in archived),'archived_max_absolute_sum':max(x['max_absolute_sum'] for x in archived),'archived_max_norm_error':max(x['max_norm_error'] for x in archived)}}
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(result,indent=2))
    print(json.dumps(result['summary'],indent=2))
if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--source',type=pathlib.Path,default=ROOT/'src')
 parser.add_argument('--archive-root',type=pathlib.Path,default=ROOT/'archived_directions')
 parser.add_argument('--out',type=pathlib.Path,default=ROOT/'results/projected_derivative_checks.json')
 args=parser.parse_args()
 with threadpool_limits(limits=1):run(args.source,args.archive_root,args.out)
