Mathematical revision support — 2026-11-12

The revised Word manuscript is delivered separately. Its mathematical supplement
is the current integrated version; no earlier standalone theory memo is included.

CONTENTS
  src/sopc_ot/                Solver source from the original submission package.
  theory_checks.py            Previously run 189-case synthetic curvature checks.
  new_checks/                All outputs from those 189 cases.
  check_projected_derivatives.py  New chain-rule, finite-difference, geometry checks.
  results/                   Recorded API, derivative and projection check outputs.
  archived_directions/        Only the direction arrays extracted from 16 archived
                             baseline.npz files. These are not complete baselines.
  archived_directions/provenance.json
                             Original file and extracted-array hashes.

REPRODUCE FROM THIS DIRECTORY
Tested numerical environment: Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0.
Install requirements.txt in an appropriate environment.

python check_projected_derivatives.py --out rerun/projected_derivative_checks.json
python theory_checks.py --source ./src --out ./rerun/curvature
PYTHONPATH=./src python verify_derivatives.py
PYTHONPATH=./src python test_api.py

The numerical checks are synthetic and are not biological replication. The
archived-direction audit checks geometry without fitting new real-data models.
They do not create a new speed benchmark or a global convergence certificate.

LICENSE
Existing LICENSE.proposed and THIRD_PARTY_NOTICES.txt are preserved. This package
does not select a public license or authorize public deposition on the authors'
behalf.
