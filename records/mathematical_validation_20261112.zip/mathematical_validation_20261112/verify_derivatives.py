"""Numerical checks of derivative formulas, gauge, and batched corrector."""
from pathlib import Path
import os,sys,json
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
ROOT=Path(__file__).resolve().parent
import numpy as np
from sopc_ot import derivatives,solve,predict,batch_solve,readout
from scipy.spatial.distance import cdist
from threadpoolctl import threadpool_limits

def check():
    rng=np.random.default_rng(915);n,m,q=31,23,4
    K=np.exp(-cdist(rng.normal(size=(n,3)),rng.normal(size=(m,3)),'sqeuclidean')/3)
    a=np.full(n,1/n);b=np.full(m,1/m);Y=np.eye(q)[np.arange(m)%q];p0=b@Y;W=Y*b[:,None]/p0;db=W-b[:,None]
    G,u,v,_,_=solve(K,a,b,tol=1e-13)
    ds=derivatives(G,a,b,db,side='source');dt=derivatives(G,a,b,db,side='target')
    gauge_gap=float(np.max(np.abs(ds['f2']-dt['f2'])))
    assert gauge_gap<1e-8
    d=np.array([.3,-.1,-.15,-.05]);f1=dt['f']@d;i,j=dt['ij'].T
    f2=dt['f2']@(d[i]*d[j]*np.where(i==j,1.,2.))
    h=1e-3;fp=[]
    for sign in [-1,1]:
        _,up,_,_,_=solve(K,a,b+sign*h*(db@d),tol=1e-13)
        g=np.log(up)-np.log(u);fp.append(g-a@g)
    d1=(fp[1]-fp[0])/(2*h);d2=(fp[1]+fp[0])/h**2
    err1=float(np.max(np.abs(d1-f1)));err2=float(np.max(np.abs(d2-f2)))
    assert err1<1e-5 and err2<1e-4,(err1,err2)
    deltas=rng.normal(scale=.01,size=(9,q));deltas-=deltas.mean(1)[:,None];ps=p0+deltas
    U0=np.column_stack([predict(np.log(u),dt,d)[0] for d in deltas])
    U,V,its,res=batch_solve(K,a,W@ps.T,U0,tol=1e-10)
    P=readout(K,a,Y,U,V);diff=0.
    for k,p in enumerate(ps):
        exact,_,_,_,_=solve(K,a,W@p,tol=1e-13)
        diff=max(diff,float(np.max(np.abs(P[:,k,:]-exact@Y/a[:,None]))))
    assert diff<1e-7
    result={'source_target_second_derivative_difference':gauge_gap,'finite_difference_first_max_error':err1,
        'finite_difference_second_max_error':err2,'batch_probability_max_error':diff,'batch_residual_max':float(res.max()),'passed':True}
    (ROOT/'results'/'derivative_checks.json').write_text(json.dumps(result,indent=2));print(result)
if __name__=='__main__':
    with threadpool_limits(limits=1):check()
