"""Executable numerical acceptance tests, no testing-framework dependency."""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import json,numpy as np
from scipy.spatial.distance import cdist
from threadpoolctl import threadpool_limits
from sopc_ot import CompositionAudit

def main():
    rng=np.random.default_rng(37);C=cdist(rng.normal(size=(43,4)),rng.normal(size=(29,4)),'sqeuclidean');C/=np.median(C)
    audit=CompositionAudit(C,np.arange(29)%4,epsilon=.2)
    ps=.8*audit.p0+.2*rng.dirichlet(np.ones(4),12)
    ref=audit.run(ps,order=0,corrector='aa2',tol=1e-10);rows=[]
    for order in [0,1,2]:
        result=audit.run(ps,order=order,tol=1e-10)
        diff=float(np.max(np.abs(result['probabilities']-ref['probabilities'])))
        assert diff<1e-7
        assert result['marginal_residual'].max()<=1.01e-10
        cached=audit.run(ps,order=order,tol=1e-10);assert cached['diagnostics']['cached_setup']
        rows.append({'order':order,'max_probability_difference':diff,'max_residual':float(result['marginal_residual'].max())})
    # Explicitly exercise fallback by restricting the chord iterations to zero.
    from sopc_ot.chord import chord_solve,factor_target
    U,V,it,res,info=chord_solve(audit.K,audit.a,audit.W@ps.T,np.tile(audit.v[:,None],(1,len(ps))),factor_target(audit.G,audit.a,audit.b),maxiter=0,tol=1e-10)
    assert info['fallback_count']==len(ps) and res.max()<1.01e-10
    # API must reject absent class mass and changing the total transported mass.
    rejected=0
    for bad in [np.zeros_like(ps),ps*2,np.full_like(ps,np.nan)]:
        try:audit.run(bad)
        except ValueError:rejected+=1
    assert rejected==3
    constructor_rejected=0
    for bad_cost,kw in [(C-1000,{}),(C+1000,{}),(C,{'base_tol':0})]:
        try:CompositionAudit(bad_cost,np.arange(29)%4,epsilon=.2,**kw)
        except ValueError:constructor_rejected+=1
    assert constructor_rejected==3
    J=audit.local_sensitivity();h=1e-4;j=2;direction=np.eye(4)[j]-audit.p0
    small=np.array([audit.p0-h*direction,audit.p0+h*direction])
    vals=audit.run(small,order=2,tol=1e-12)['probabilities']
    derivative_error=float(np.max(np.abs((vals[:,1]-vals[:,0])/(2*h)-J[:,j])))
    assert derivative_error<1e-5 and np.max(np.abs(J.sum(2)))<1e-8
    result={'passed':True,'equivalence':rows,'forced_fallback_count':info['fallback_count'],'invalid_inputs_rejected':rejected,'invalid_constructors_rejected':constructor_rejected,'local_probability_derivative_error':derivative_error}
    (Path(__file__).parent/'results/api_checks.json').write_text(json.dumps(result,indent=2));print(result)

if __name__=='__main__':
    with threadpool_limits(limits=1):main()
