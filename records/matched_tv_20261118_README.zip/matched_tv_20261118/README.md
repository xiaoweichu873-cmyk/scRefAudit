# Matched-TV supplementary reproduction materials, 18 November 2026

This compact package contains exact prepared cost matrices, baseline probabilities,
original directions and anchors, unchanged solver code, all scenario diagnostics,
sample and donor summaries, the fixed analysis specification, and numerical checks.
The separate full archive `Matched_TV_Code_Results_20261118.zip` also contains all
scenario-by-cell probability arrays; those large arrays are not duplicated here.
The original result JSON records are under `archived_result_metadata/`, not under
`results/`, so they do not incorrectly trigger a completed-run checkpoint.

## Reproduce

Use Python 3.12 and install requirements.txt. From this directory run:

    python run_matched_tv.py --replay-all --workers 3
    python check_boundary_precision.py
    python summarize_matched_tv.py

The first command regenerates the complete results/ arrays from packaged matrices,
without count downloads. After a completed run, move results/ aside to force a new
run. The numerical solver, original validation script and frozen donor metadata are
retained under source/ in their original relative layout. The replay starts at the prepared matrices. Count-to-PCA regeneration is outside this archive. The exact computation protocol
and numerical environment accompany this package.

The primary endpoint is any corrected label change among all query cells; the
intended-anchor one-direction hit is a distinct secondary endpoint. At matched TV,
global detection gains persist in liver myeloid, but not in the two lung compartments.
The independent acceleration benchmark and review-ranking analyses were not rerun.
License terms and original data attribution remain unchanged.
