"""Re-export figure panels from the frozen source tables; no OT fitting.
Run from any directory: python figure_sources/regenerate_figures.py
Outputs are written to figure_sources/regenerated (PDF and PNG).
The submission PDFs for unchanged figures are the original vector exports.
"""
from pathlib import Path
from decimal import Decimal, ROUND_HALF_UP
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.lines import Line2D
DATA = Path(__file__).resolve().parents[1] / 'source_data'
F = Path(__file__).resolve().parent / 'regenerated'
F.mkdir(exist_ok=True)
def save(fig, name, tight=False):
    opts = {'bbox_inches':'tight'} if tight else {}
    fig.savefig(F/(name+'.pdf'), **opts)
    fig.savefig(F/(name+'.png'), dpi=300, **opts)
    plt.close(fig)
def style(size=9):
    plt.rcdefaults()
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':size,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'savefig.dpi':300,'savefig.facecolor':'white'})
style()

# Figure 1: original workflow plotting commands.
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':13,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':300})
teal='#167D9A';gray='#929CA4';brown='#9F6349'
fig,ax=plt.subplots(figsize=(9,5.2));ax.set(xlim=(0,10),ylim=(-.25,6));ax.axis('off')
def box(x,y,w,h,title,detail):
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.12',facecolor='#F2F6F8',edgecolor='#677B87',lw=1.2));ax.text(x+w/2,y+h-.18,title,ha='center',va='top',fontsize=12.5,fontweight='bold');ax.text(x+w/2,y+h-.65,detail,ha='center',va='top',fontsize=12,linespacing=1.5)
def arrow(a,b):ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=15,color='#526E7B',lw=1.4))
box(.25,4.3,3.8,1.35,'Fixed cells and RNA geometry','Reference labels + query cells\nBaseline transport fit')
box(5.35,4.3,4.1,1.35,'Reusable numerical information','Factor the baseline Schur matrix\nCompute composition derivatives')
arrow((4.2,4.95),(5.15,4.95))
box(.25,2.15,3.8,1.4,'Composition scenarios','Donor mixtures or random directions\nDerivative-directed stress tests')
box(5.35,2.15,4.1,1.4,'Corrected transport solutions','Optional Taylor prediction\nShared curvature + guarded fallback')
arrow((7.4,4.15),(7.4,3.75));arrow((5.5,4.2),(3.9,3.65));arrow((4.2,2.85),(5.15,2.85))
box(1.35,.1,7.05,1.25,'Sensitivity profiles and review priorities','Confirmed label changes across scenarios\nSensitivity ranking alongside confidence and marker evidence')
arrow((7.4,1.98),(6.9,1.53));arrow((2.15,1.98),(3.1,1.53))
fig.tight_layout();save(fig,'Figure_01',tight=True)

style()
OUT=DATA/'immune'
TASKS=['kang_f0','kang_f1','hao_f0','hao_f1']
NAMES={'kang_f0':'Kang / fold 1','kang_f1':'Kang / fold 2','hao_f0':'Hao / donor P1','hao_f1':'Hao / donor P2'}
def biological_plot(bio):
    f,axes=plt.subplots(2,2,figsize=(7.2,6.8));short={'CD14+ Monocytes':'CD14 mono','FCGR3A+ Monocytes':'FCGR3A mono','Dendritic cells':'Dendritic','Megakaryocytes':'Megakaryocytes','CD4 T cells':'CD4 T','CD8 T cells':'CD8 T','B cells':'B','NK cells':'NK'}
    for ax,task in zip(axes.ravel(),TASKS):
        d=OUT/'confirmation'/f'{task}_eps0.05';a=pd.read_csv(d/'types_mild.csv',index_col=0)
        b=pd.read_csv(d/'types_full.csv',index_col=0).reindex(a.index) if (d/'types_full.csv').exists() else None
        y=np.arange(len(a));ax.barh(y-.18,a.switch_any*100,.34,color='#31688E',label='Local mixture')
        if b is not None:ax.barh(y+.18,b.switch_any*100,.34,color='#D99343',label='Full donor mixture')
        ax.set_yticks(y,[f'{short.get(x,x)}\nn={int(a.loc[x,"n"])}' for x in a.index],fontsize=8);ax.invert_yaxis();ax.set_title(NAMES[task]+('\nFull mixture: time-censored' if b is None else ''),fontsize=9);ax.set_xlabel('Cells changing label (%)');ax.set_xlim(0,max(10,max(a.switch_any.max(),0 if b is None else b.switch_any.max())*110));ax.grid(axis='x',alpha=.15)
    handles,labels=axes[0,0].get_legend_handles_labels();f.legend(handles,labels,frameon=False,fontsize=8,loc='lower center',ncol=2,bbox_to_anchor=(.5,-.02));f.tight_layout(rect=[0,.04,1,1]);save(f,'Figure_02',tight=True)
biological_plot(None)

style()
def protein_plot(bio):
    f=plt.figure(figsize=(7.2,6.1));gs=f.add_gridspec(2,2,height_ratios=[1.1,1]);axes=[f.add_subplot(gs[0,0]),f.add_subplot(gs[0,1]),f.add_subplot(gs[1,:])];records=[]
    for ax,task in zip(axes[:2],['hao_f0','hao_f1']):
        cells=pd.read_csv(DATA/'immune/protein_scores.csv'); cells=cells[cells.task==task]
        score=cells.protein_contrast.to_numpy();labels=cells.author_type.to_numpy();switch=cells.switcher.to_numpy()
        values=[];ticks=[];colors=[]
        for celltype in ['CD4 T','CD8 T']:
            for status in [False,True]:
                mask=(labels==celltype)&(switch==status);values.append(score[mask]);ticks.append(f'{celltype}\n'+('switch' if status else 'stable')+f'\nn={mask.sum()}');colors.append('#D99343' if status else '#31688E')
                records.append({'task':task,'author_type':celltype,'switcher':bool(status),'n':int(mask.sum()),'median_protein_score':float(np.median(score[mask])) if mask.any() else None})
        bp=ax.boxplot(values,patch_artist=True,showfliers=False,widths=.6)
        for box,color in zip(bp['boxes'],colors):box.set_facecolor(color);box.set_alpha(.65)
        ax.set_xticks(range(1,5),ticks,fontsize=8.5);ax.set_title(NAMES[task]);ax.set_ylabel('Mean log(1 + CD4 ADT)\n− mean log(1 + CD8 ADT)',fontsize=9);ax.axhline(0,color='#AAAAAA',lw=.7,ls='--')
    df=bio[(bio.eps==.05)&(bio.workload=='mild')].set_index('task').reindex(TASKS);x=np.arange(4)
    axes[2].bar(x-.17,df.error_auc_flip,.32,label='Composition switching',color='#D99343');axes[2].bar(x+.17,df.error_auc_entropy,.32,label='Base entropy',color='#31688E');axes[2].set_xticks(x,['K1','K2','H1','H2']);axes[2].set_ylim(0,1.08);axes[2].axhline(.5,ls='--',color='#AAAAAA',lw=.7);axes[2].set_ylabel('AUROC for label disagreement');axes[2].set_title('Ranking disagreements with author labels');axes[2].legend(frameon=False,fontsize=7,loc='upper left')
    f.tight_layout();save(f,'Figure_03',tight=True)
protein_plot(pd.read_csv(DATA/'immune/biological_summary.csv'))

style(9)
ratios=pd.read_csv(DATA/'immune/followup/ratios_to_quadratic.csv')
names={'hao_f0':'H1','hao_f1':'H2','kang_f0':'K1','kang_f1':'K2'}
fig,axs=plt.subplots(1,2,figsize=(7.4,4.8),gridspec_kw={'width_ratios':[1.5,1]})
a=ratios.dropna(subset=['reuse_AA2']).reset_index(drop=True)
y=np.arange(len(a));vals=a.reuse_AA2.to_numpy()
axs[0].barh(y,vals,height=.62,color=['#2865a6' if v>=1 else '#aa5d40' for v in vals])
axs[0].set_yticks(y,[f'{names[r.task]}  m={int(r.m)} B={int(r.B)}  ε={r.eps:g}' for _,r in a.iterrows()],fontsize=7)
axs[0].invert_yaxis();axs[0].set_xlim(0,9.6)
for yy,v in zip(y,vals):axs[0].text(v+.1,yy,f'{v:.2f}',va='center',fontsize=8)
axs[0].set_xlabel('AA2 time / quadratic + curvature time',fontsize=8)
axs[0].set_title('A  Complete comparisons with AA2',loc='left',fontsize=10)
axs[0].set_xticks([0,2,4,6,8])
b=ratios.dropna(subset=['reuse_chord']).reset_index(drop=True);y=np.arange(len(b))
axs[1].scatter(b.reuse_chord,y,s=24,color='#2865a6')
axs[1].set_yticks(y,[f'{names[r.task]}  {int(r.m)} / {int(r.B)} / {r.eps:g}' for _,r in b.iterrows()],fontsize=7)
axs[1].invert_yaxis();axs[1].set_xlim(.8,1.57);axs[1].set_xticks([.8,1.,1.2,1.4])
axs[1].set_xlabel('Shared curvature time /\nquadratic + curvature time',fontsize=8)
axs[1].set_title('B  Added value of prediction',loc='left',fontsize=10)
for ax in axs:
    ax.axvline(1,color='#555555',ls='--',lw=1)
    ax.grid(axis='x',alpha=.15);ax.set_axisbelow(True)
fig.tight_layout(w_pad=1.8);save(fig,'Figure_04',tight=True)

style()
LABELS={'reuse_AA2':'Batched AA2','reuse_chord':'Shared curvature','quadratic_chord':'Quadratic + curvature',
        'SSNS_CG_AA2':'SSNS + AA2','SPLR_CG_AA2':'SPLR + AA2'}
COLORS={'reuse_AA2':'#7b7f86','reuse_chord':'#47957b','quadratic_chord':'#2767a1','SSNS_CG_AA2':'#c78835','SPLR_CG_AA2':'#9063a9'}

summary=pd.read_csv(DATA/'immune/followup/timing_summary.csv')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False})
fig,axs=plt.subplots(2,2,figsize=(7.2,6.5),constrained_layout=True)
for j,task in enumerate(['kang_f0','hao_f0']):
    ss=summary[(summary.task==task)&(summary.eps==.05)&(summary.B==64)]
    for method in LABELS:
        dd=ss[ss.method==method].sort_values('m');ok=dd.n_ok==3
        axs[0,j].plot(dd.m,np.where(ok,dd.total_s_median,np.nan),'o-',lw=1.5,ms=4,color=COLORS[method],label=LABELS[method])
        for _,row in dd[ok].iterrows():axs[0,j].vlines(row.m,row.total_s_min,row.total_s_max,color=COLORS[method],lw=1)
        for _,r in dd[~ok].iterrows():
            missing=[mm for mm in LABELS if len(ss[(ss.m==r.m)&(ss.method==mm)&(ss.n_ok<3)])]
            offset=(missing.index(method)-(len(missing)-1)/2)*140
            axs[0,j].scatter([r.m+offset],[180],marker='x',color=COLORS[method],s=36,linewidths=1.5)
        axs[1,j].plot(dd.m,dd.observed_peak_rss_mib_max,'o-',color=COLORS[method],lw=1.5,ms=4)
        if (~ok).any():axs[1,j].scatter(dd.loc[~ok,'m'],dd.loc[~ok,'observed_peak_rss_mib_max'],marker='x',color=COLORS[method],s=45)
    axs[0,j].set(yscale='log',ylabel='Audit elapsed time (s)',title=('A  Kang fold 1' if j==0 else 'B  Hao P1'))
    axs[0,j].axhline(180,color='#aaa',ls=':',lw=.7)
    axs[1,j].set(ylabel='Observed peak RSS (MiB)',xlabel='Distinct reference cells',title=('C  Kang memory' if j==0 else 'D  Hao memory'))
    for ax in axs[:,j]:ax.set_xticks([1200,2400,4800]);ax.grid(axis='y',alpha=.18)
handles,labels=axs[0,0].get_legend_handles_labels()
handles.append(Line2D([],[],color='#333333',marker='x',ls='None'));labels.append('Incomplete repeats')
fig.legend(handles,labels,loc='outside lower center',ncol=3,frameon=False)
fig.suptitle('Fixed 3,000 query cells · 64 local scenarios · single CPU thread',fontsize=12)
save(fig,'Figure_05')

style(10)
d=pd.read_csv(DATA/'tissue/paired_donor_comparisons.csv');a=pd.read_csv(DATA/'tissue/active_search.csv');orig=pd.read_csv(DATA/'tissue/original_active_search.csv');risk=pd.read_csv(DATA/'tissue/selective_prediction.csv');ood=pd.read_csv(DATA/'tissue/missing_class_challenge.csv');diag=pd.read_csv(DATA/'tissue/run_diagnostics.csv')
groups=['HCC_Myeloid','IPF_Epithelial','IPF_Mesenchymal'];labels=['HCC myeloid\n10 donors','Lung epithelial\n30 donors','Lung mesenchymal\n30 donors'];colors=['#778698','#167D9A'];plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.facecolor':'white'})
fig,axs=plt.subplots(1,2,figsize=(11,4.6));ax=axs[0];x=np.arange(3)
for j,method in enumerate(['random','directed']):
 vals=[a[(a.group==g)&(a.radius==.1)&(a.method==method)].groupby('subject').query_hit_fraction.mean().mean()*100 for g in groups];b=ax.bar(x+(j-.5)*.34,vals,.32,color=colors[j],label=['Random','Derivative directed'][j]);ax.bar_label(b,fmt='%.2f',padding=3,fontsize=9)
ax.set_xticks(x,labels);ax.set_ylim(0,14);ax.set_ylabel('Cells with ≥1 label change (%)');ax.set_title('A  Equal budget in held-out human samples',loc='left',fontweight='bold');ax.legend(frameon=False,fontsize=9)
ax=axs[1];names=['kang_f0','kang_f1','hao_f0','hao_f1'];x=np.arange(4)
for j,method in enumerate(['random','directed']):
 vals=[int(orig[(orig.task==n)&(orig.radius==.1)&(orig.method==method)].all_query_hits.iloc[0]) for n in names];b=ax.bar(x+(j-.5)*.34,vals,.32,color=colors[j],label=method);ax.bar_label(b,padding=3,fontsize=9)
ax.set_xticks(x,['Kang 1','Kang 2','Hao P1','Hao P2']);ax.set_ylim(0,380);ax.set_ylabel('Cells with ≥1 label change (of 3,000)');ax.set_title('B  Original manuscript tasks',loc='left',fontweight='bold');fig.tight_layout(rect=(0,.09,1,1));fig.text(.5,.025,'Up to 32 scenarios per strategy; centered log-weight L2 radius 0.10. Detection of model sensitivity, not biological error.',ha='center',fontsize=9);save(fig,'Figure_06')
fig,axs=plt.subplots(1,2,figsize=(11,4.6));ax=axs[0]
for k,g in enumerate(groups):
 row=d[(d.analysis==g+' selective80')&(d.method=='calibrated_confidence_sensitivity')&(d.baseline=='calibrated_confidence')].iloc[0];v=row.paired_difference*100;lo=row.bootstrap_low*100;hi=row.bootstrap_high*100;ax.errorbar(v,2-k,xerr=[[v-lo],[hi-v]],fmt='o',color=colors[1],capsize=4);ax.text(hi+.035,2-k,f'{v:+.2f} pp',va='center',fontsize=9)
ax.axvline(0,color='gray',lw=.9,ls='--');ax.set_yticks([2,1,0],['HCC myeloid','Lung epithelial','Lung mesenchymal']);ax.set_xlim(-1.12,.95);ax.set_xlabel('Change in retained disagreement (percentage points)\nSensitivity + confidence minus confidence (lower is better)');ax.set_title('A  Matched 80% fine-label coverage',loc='left',fontweight='bold')
ax=axs[1];x=np.arange(3)
for j,m in enumerate(['confidence','switch_entropy','reference_distance']):
 vals=[ood[(ood.group==g)&(ood.method==m)].groupby('subject').OOD_AUROC.mean().mean() for g in groups];ax.bar(x+(j-1)*.24,vals,.23,color=['#778698','#167D9A','#C58A36'][j],label=['Confidence','Switch rate','Reference distance'][j])
ax.set_xticks(x,['HCC\nmyeloid','Lung\nepithelial','Lung\nmesenchymal']);ax.set_ylim(0,1.08);ax.set_ylabel('Withheld-class detection AUROC');ax.set_title('B  Controlled missing-reference-class test',loc='left',fontweight='bold');handles,leglabels=ax.get_legend_handles_labels();fig.tight_layout(rect=(0,.20,1,1));fig.legend(handles,leglabels,loc='lower center',bbox_to_anchor=(.76,.10),ncol=3,fontsize=8,frameon=False);fig.text(.5,.025,'Author labels are benchmark targets. Donor bootstrap intervals are exploratory and conditional on fitted splits.\nThe two lung compartments share donors; missing-class AUROC is defined for 26 mesenchymal donors.',ha='center',fontsize=9);save(fig,'Figure_S1')

style(13)
v=pd.read_csv(DATA/'tissue/selective_prediction.csv');v=v[v.method.isin(['calibrated_confidence','calibrated_confidence_sensitivity'])];v=v.groupby(['group','subject','coverage','method']).retained_disagreement.mean().reset_index();vv=v.groupby(['group','coverage','method']).retained_disagreement.mean().reset_index()
fig,axes=plt.subplots(1,3,figsize=(10,3.4),layout='constrained')
for ax,g,title in zip(axes,['HCC_Myeloid','IPF_Epithelial','IPF_Mesenchymal'],['Liver myeloid','Lung epithelial','Lung mesenchymal']):
 for method,col,label in [('calibrated_confidence',gray,'Confidence'),('calibrated_confidence_sensitivity',teal,'+ Sensitivity')]:
  q=vv[(vv.group==g)&(vv.method==method)];ax.plot(q.coverage*100,q.retained_disagreement*100,'o-',color=col,label=label,markersize=4)
 ax.set_title(title,fontsize=13);ax.set_xlabel('Labels retained (%)');ax.set_xticks([50,70,90,100]);ax.tick_params(labelsize=11);ax.set_ylim(bottom=0)
axes[0].set_ylabel('Author-label disagreement (%)');axes[1].legend(fontsize=9,loc='upper left');save(fig,'Figure_S2')

style(11)
teal='#167D9A';gray='#929CA4'
rv=pd.read_csv(DATA/'review/review_margin_primary.csv').set_index(['task','references']).sort_index()
counts=pd.read_csv(DATA/'applicability/range_summary.csv')
ss=counts[(counts.radius==.1)&(counts.budget==32)].set_index(['references','taxonomy']).loc[[(300,'native'),(1200,'native'),(1200,'merged'),(1200,'binary_T')]].reset_index()
fig,axes=plt.subplots(1,2,figsize=(10.5,4.5),layout='constrained');x=np.arange(4)
axes[0].bar(x-.18,ss.random,.36,color=gray,label='Random');axes[0].bar(x+.18,ss.directed,.36,color=teal,label='Directed');axes[0].set_xticks(x,['Native\n300 refs','Native\n1,200 refs','Merged\n1,200 refs','Binary\n1,200 refs']);axes[0].set_ylabel('Sensitive cells found per 1,000');axes[0].set_ylim(0,110);axes[0].legend(fontsize=10);axes[0].set_title('A  Search yield at 32 scenarios',loc='left',fontsize=13)
methods=['confidence','margin','linear_radius']
for _,row in rv.iterrows():axes[1].plot(range(3),row[methods],color=gray,alpha=.65,lw=1,marker='o',markersize=3)
means=rv[methods].mean();axes[1].plot(range(3),means,color=teal,lw=3,marker='o');axes[1].set_xticks(range(3),['Confidence','Winning\nmargin','Linearized\nradius']);axes[1].set_xlim(-.25,2.25);axes[1].set_ylim(0,112);axes[1].set_ylabel('Sensitive cells among first 100 reviewed');axes[1].set_title('B  Review yield on random scenarios',loc='left',fontsize=13)
for x,m in enumerate(means):axes[1].text(x,m+(5 if x!=1 else -10),str(Decimal(str(m)).quantize(Decimal('.01'),rounding=ROUND_HALF_UP)),ha='center',color=teal,fontweight='bold')
save(fig,'Figure_07')

cm=pd.read_csv(DATA/'review/hcc_ot_confusion.csv');labels=sorted(cm.author_label.unique(),key=lambda v:int(v[1:]));fig,axes=plt.subplots(1,2,figsize=(10,4.7),layout='constrained')
for ax,condition,title in zip(axes,['Normal','Tumor'],['A  Non-tumor liver','B  Primary tumor']):
    t=cm[cm.condition==condition].pivot(index='author_label',columns='predicted_label',values='n').reindex(index=labels,columns=labels).fillna(0);arr=t.to_numpy();arr=100*arr/np.maximum(arr.sum(axis=1,keepdims=True),1)
    im=ax.imshow(arr,vmin=0,vmax=100,cmap='Blues');ax.set_xticks(range(len(labels)),labels,rotation=90,fontsize=9);ax.set_yticks(range(len(labels)),labels,fontsize=9);ax.set_xlabel('OT label');ax.set_ylabel('Author cluster');ax.set_title(title,loc='left',fontsize=13)
fig.colorbar(im,ax=axes,shrink=.8,label='Cells within author cluster (%)');save(fig,'Figure_S3')

style(9)
NAMES=dict(zip(TASKS,['Kang fold 1','Kang fold 2','Hao P1','Hao P2']))
dist=pd.read_csv(DATA/'supervisor_additions/composition_distance_scenarios.csv')
ds=pd.read_csv(DATA/'supervisor_additions/composition_distance_summary.csv')
fig,axs=plt.subplots(2,2,figsize=(7,5.4),layout='constrained')
for task,ax in zip(TASKS,axs.flat):
    for family,color in [('mild','#147D92'),('full','#D7833E')]:
        a=dist[(dist.task==task)&(dist.family==family)]
        if a.empty:continue
        rho=ds[(ds.task==task)&(ds.family==family)].spearman_rho.iloc[0]
        ax.scatter(100*a.tv,100*a.switch_fraction,s=10,alpha=.5,color=color,label=('Local' if family=='mild' else 'Full mixture')+f' (ρ={rho:.2f})',linewidths=0)
    ax.set(title=NAMES[task],xlabel='Composition TV distance (%)',ylabel='Cells switching per scenario (%)')
    ax.legend(frameon=False,fontsize=7,loc='upper left')
save(fig,'Figure_S4',tight=True)
pf=pd.read_csv(DATA/'supervisor_additions/cell_type_donor_profiles.csv')
fig,axs=plt.subplots(4,3,figsize=(7.1,8.7),layout='constrained')
for row,task in enumerate(TASKS):
    a=pf[(pf.task==task)&(pf.level=='author_type')].sort_values('author_type')
    for col,(metric,label,mult) in enumerate([('switch_frequency_mean','Mean switching frequency (%)',100),('max_probability_change_median','Median maximum score change',1),('entropy_median','Median baseline entropy (nats)',1)]):
        ax=axs[row,col];yy=np.arange(len(a));ax.barh(yy,mult*a[metric],color=['#147D92','#48789B','#9B6EAD'][col])
        ax.set_yticks(yy,a.author_type if col==0 else ['']*len(a));ax.invert_yaxis();ax.tick_params(labelsize=7)
        ax.set_xlabel(label,fontsize=7)
        if col==0:ax.set_title(NAMES[task],loc='left',fontsize=9)
save(fig,'Figure_S5',tight=True)
ab=pd.read_csv(DATA/'supervisor_additions/four_arm_ablation_summary.csv')
methods=['reuse_AA2','reuse_chord','linear_chord','quadratic_chord']
fig,axs=plt.subplots(1,2,figsize=(7.1,3.4),layout='constrained')
colors=['#91979F','#407E96','#B98451','#137F73'];x=np.arange(4)
for j,m in enumerate(methods):
    a=ab[ab.method==m].set_index('task').loc[TASKS]
    for ax,key in zip(axs,['time_s','iterations']):
        ax.bar(x+(j-1.5)*.19,a[key],.18,color=colors[j],label=['Reuse + AA2','Reuse + shared curvature','Linear + shared curvature','Quadratic + shared curvature'][j])
        ax.set_yscale('log');ax.set_xticks(x,['K1','K2','H1','H2'])
axs[0].set(title='A  Total audit time',ylabel='Seconds (log scale)')
axs[1].set(title='B  Reported correction iterations',ylabel='Mean per scenario (log scale)')
fig.legend(*axs[0].get_legend_handles_labels(),loc='outside lower center',ncol=2,frameon=False,fontsize=8)
save(fig,'Figure_S6',tight=True)
print('Regenerated 13 figures from frozen source data:',F)
