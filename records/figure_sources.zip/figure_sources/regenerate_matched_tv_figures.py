from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
TV=ROOT.parent/'matched_tv_20261118'
OUT=ROOT/'regenerated';OUT.mkdir(exist_ok=True)
new=pd.read_csv(TV/'summary/matched_TV_summary.csv')
old=pd.read_csv(TV/'summary/original_log_radius_comparison.csv')
groups=['HCC_Myeloid','IPF_Epithelial','IPF_Mesenchymal']
names=['Liver\nmyeloid','Lung\nepithelial','Lung\nmesenchymal']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none'})
fig,axes=plt.subplots(2,2,figsize=(9.2,7.1),layout='constrained')
colors={'Random':'#92989F','Directed':'#087E8B'}

def bars(ax,random,directed,ticks,title,ylabel,letter):
    x=np.arange(len(ticks));w=.34
    for shift,values,name in [(-w/2,random,'Random'),(w/2,directed,'Directed')]:
        rects=ax.bar(x+shift,values,w,label=name,color=colors[name])
        ax.bar_label(rects,labels=[f'{v:.2f}' if max(random+directed)<30 else f'{v:.0f}' for v in values],padding=3,fontsize=8)
    ax.set_xticks(x,ticks);ax.set_ylim(0,max(random+directed)*1.25);ax.set_title(title,fontsize=11,pad=10)
    ax.set_ylabel(ylabel,fontsize=10);ax.grid(axis='y',alpha=.18);ax.set_axisbelow(True)
    ax.text(-.14,1.05,letter,transform=ax.transAxes,fontweight='bold',fontsize=14)

logrows=[old[old.analysis.str.startswith(g)].iloc[0] for g in groups]
bars(axes[0,0],[100*r.baseline_mean for r in logrows],[100*r.method_mean for r in logrows],names,
     'Equal log-weight radius 0.10','Cells with any label switch (%)','A')
main=[new[(new.group==g)&(new.tv==.01)&(new.endpoint=='query_hit_fraction')].iloc[0] for g in groups]
bars(axes[0,1],[100*r.random_mean for r in main],[100*r.directed_mean for r in main],names,
     'Equal actual composition TV 1%','Cells with any label switch (%)','B')
target=[new[(new.group==g)&(new.tv==.01)&(new.endpoint=='anchor_hit_fraction')].iloc[0] for g in groups]
bars(axes[1,0],[100*r.random_mean for r in target],[100*r.directed_mean for r in target],names,
     'Specified cell probed once at TV 1%','Intended-anchor label switches (%)','C')
bars(axes[1,1],[118,155,292,224],[151,200,323,268],['Kang 1','Kang 2','Hao P1','Hao P2'],
     'Original immune tasks at log radius 0.10','Cells with any label switch (count)','D')
axes[0,0].legend(frameon=False,loc='upper left',fontsize=9)
fig.savefig(OUT/'Figure_06.pdf');fig.savefig(OUT/'Figure_06.png',dpi=300)
plt.close(fig)

fig,axes=plt.subplots(1,3,figsize=(10.8,3.7),layout='constrained')
for i,(ax,g) in enumerate(zip(axes,groups)):
    v=new[(new.group==g)&(new.endpoint=='query_hit_fraction')].sort_values('tv')
    ax.plot(100*v.tv,100*v.random_mean,'s--',color=colors['Random'],label='Random',lw=2)
    ax.plot(100*v.tv,100*v.directed_mean,'o-',color=colors['Directed'],label='Directed',lw=2)
    ax.axvline(1,color='#b5b5b5',lw=1,zorder=0)
    ax.set_xticks([.5,1,2]);ax.set_ylim(bottom=0)
    ax.set_title(names[i].replace('\n',' ')+'\n'+f"n = {int(v.iloc[0].n_donors)} donors",fontsize=11)
    ax.set_xlabel('Actual composition TV (%)')
    ax.grid(axis='y',alpha=.18);ax.text(-.12,1.06,'ABC'[i],transform=ax.transAxes,fontsize=13,fontweight='bold')
axes[0].set_ylabel('Cells with any label switch (%)');axes[-1].legend(frameon=False)
fig.savefig(OUT/'Figure_S7.pdf');fig.savefig(OUT/'Figure_S7.png',dpi=300)
print('Built Figure 6 and Figure S7 from archived summary tables')
