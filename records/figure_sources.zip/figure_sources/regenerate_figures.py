"""Export the current 7 main and 7 supplementary figures from frozen tables."""
from pathlib import Path
import subprocess, sys
root=Path(__file__).resolve().parent
for name in ['regenerate_legacy_figures.py','regenerate_matched_tv_figures.py']:
    subprocess.run([sys.executable,str(root/name)],check=True)
