"""Package completed calculations and render a self-contained Chinese report."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import base64
import hashlib
import html
import json
import re
import shutil

ROOT=Path(__file__).resolve().parent
DEST=ROOT/'deliverables'; DEST.mkdir(exist_ok=True)
SUM=ROOT/'summary'
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(2**20),b''): h.update(chunk)
    return h.hexdigest()

def inline(value):
    return re.sub(r'\*\*(.*?)\*\*',r'<strong>\1</strong>',html.escape(value))

def render_markdown(text):
    out=[]; table=False; listing=False; para=[]
    def flush():
        if para:
            out.append('<p>'+inline(' '.join(para))+'</p>');para.clear()
    for line in text.splitlines()+['']:
        if not line.startswith('|') and table:
            out.append('</tbody></table></div>');table=False
        if not line.startswith('- ') and listing:
            out.append('</ul>');listing=False
        if not line.strip(): flush();continue
        if line.startswith('#'):
            flush();level=len(line)-len(line.lstrip('#'));out.append(f'<h{level}>'+inline(line[level:].strip())+f'</h{level}>')
        elif line.startswith('|'):
            flush();cells=line.strip('|').split('|')
            if all(re.fullmatch(r'\s*[:\-]+\s*',c) for c in cells):continue
            if not table:
                out.append('<div class="table-wrap"><table><thead><tr>'+''.join('<th>'+inline(c.strip())+'</th>' for c in cells)+'</tr></thead><tbody>');table=True
            else: out.append('<tr>'+''.join('<td>'+inline(c.strip())+'</td>' for c in cells)+'</tr>')
        elif line.startswith('- '):
            flush()
            if not listing:out.append('<ul>');listing=True
            out.append('<li>'+inline(line[2:])+'</li>')
        elif line.startswith('!['):
            flush();data=base64.b64encode((SUM/'matched_TV_detection.png').read_bytes()).decode()
            out.append('<figure><img alt="Matched TV detection comparison" src="data:image/png;base64,'+data+'"><figcaption>蓝色：定向搜索；橙色：随机搜索。纵轴为供者等权平均，竖线标记预先指定的 TV=1% 主分析。</figcaption></figure>')
        else:para.append(line)
    return '\n'.join(out)

report='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>同等 TV 补充分析 · 2026-11-18</title><style>
body{font-family:system-ui,-apple-system,"Noto Sans CJK SC","Microsoft YaHei",sans-serif;background:#f5f7fa;color:#172438;margin:0;line-height:1.75}main{max-width:1120px;margin:24px auto;padding:36px;background:white;border-radius:12px}h1{font-size:29px;line-height:1.4}h2{font-size:22px;margin-top:32px;color:#124b73}p,li{font-size:16px}strong{font-weight:700}table{border-collapse:collapse;font-size:14px;width:100%;font-variant-numeric:tabular-nums}th,td{padding:10px 12px;border-bottom:1px solid #dce4eb;text-align:left}th{background:#eef4f8}td:not(:first-child){text-align:right}.table-wrap{overflow-x:auto}img{width:100%;height:auto}figure{margin:24px 0}figcaption{font-size:13px;color:#5b6877}@media print{body{background:white}main{margin:0;padding:0}h2{break-after:avoid}}@media(max-width:650px){main{margin:0;padding:18px}h1{font-size:24px}}
</style><main>'''+render_markdown((SUM/'Matched_TV_Report_20261118.md').read_text())+'</main></html>'
(DEST/'Matched_TV_Report_20261118.html').write_text(report)
shutil.copy2(SUM/'matched_TV_summary.csv',DEST/'Matched_TV_Summary_20261118.csv')

old=ROOT/'source/OT_algorithm_extension_code_results_20261105/ot_sensitivity_validation_20261105'
include=[ROOT/x for x in ['README.md','protocol.json','requirements.txt','run_matched_tv.py','summarize_matched_tv.py','check_boundary_precision.py','package_results.py','manuscript_supplement.txt','run_status.json','full_run.log','pilot.log','boundary_check.log']]
for directory in ['prepared','results','summary','boundary_precision']:
    include.extend(p for p in (ROOT/directory).rglob('*') if p.is_file())
include += [old/'protocol.json',old/'scripts/02_validation.py',old/'results/paired_donor_comparisons.csv']
include += list((old/'previous/source/sopc_ot').glob('*.py'))
include += list((old/'results/frozen').glob('*/*/*.json'))
include += list((old/'results/frozen').glob('*/donor_folds.json'))
include += [DEST/'Matched_TV_Report_20261118.html',DEST/'Matched_TV_Summary_20261118.csv']
include=sorted(set(include))
provenance={'input_archives':[{'filename':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted((ROOT/'downloads').glob('*.zip'))],
            'new_code_and_protocol':[{'path':p.name,'sha256':sha(p)} for p in [ROOT/'run_matched_tv.py',ROOT/'summarize_matched_tv.py',ROOT/'protocol.json']],
            'software':'Original numerical solver modules are copied unchanged; only scenario generation, original-input reconstruction and supplemental summaries are added.'}
(ROOT/'provenance.json').write_text(json.dumps(provenance,indent=2));include.append(ROOT/'provenance.json')
manifest=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in include]
(ROOT/'MANIFEST_SHA256.json').write_text(json.dumps(manifest,indent=2))
include.append(ROOT/'MANIFEST_SHA256.json')
target=DEST/'Matched_TV_Code_Results_20261118.zip'
with ZipFile(target,'w',ZIP_DEFLATED,compresslevel=1) as z:
    for p in include: z.write(p,Path('matched_tv_20261118')/p.relative_to(ROOT))
with ZipFile(target) as z:
    bad=z.testzip()
    if bad:raise RuntimeError('Archive CRC failed: '+bad)
print(json.dumps({'files':len(include),'archive_bytes':target.stat().st_size,'archive_sha256':sha(target),'CRC':'all files passed'},indent=2))
