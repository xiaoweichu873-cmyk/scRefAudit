# Supplementary Data U1 — KL-unbalanced OT extension

For **Efficient reference composition sensitivity analysis for single-cell annotation**.
Prepared 23 November 2026. This is an exploratory extension using the same
development inputs for the initial comparison and the revised fallback retest.

## Principal results

The revised shared-curvature method was faster in **57/96** configurations.
The median paired audit ratio was **1.3424×**, or **1.2633×** after adding common
kernel construction and baseline solution time. Local log-proportion changes
(radius 0.10) had a median of **2.2640×**; larger changes (0.50), **0.9777×**.
The full range was **0.2894–6.2553×**. All 24 configurations at τ=0.5 were slower.
Preparation, correction, fallback and normalized class-score readout are charged.
These are not whole single-cell workflow times or peak-memory measurements.

The initial grid compared five controls plus shared curvature (1,728 timings).
After changing only fallback centering, all 96 configurations were retested
against the control selected from the initial three-repeat medians (576 more
timings). The retest is not an independent validation or a second full five-way
competition. Both stages and the unsuccessful development records are retained.

The revised scenarios showed zero label disagreements with paired controls;
maximum score difference was 5.42e-7. Independent POT checks at 48 distinct
endpoints also had zero label disagreements, with maximum score difference
5.41e-8. Numerical agreement does not establish biological label accuracy.

## Contents

| Path | Contents |
|---|---|
| `selected_inputs/` | Six exact prepared query-by-reference matrices and archived metadata |
| `code/uot_core.py` | Initial solver, controls and shared curvature |
| `code/shared_centered_fallback.py` | Revised shared method with scalar-centered fallback |
| `code/benchmark.py` | Initial full grid; `--smoke` runs two small configurations |
| `code/benchmark_revised.py` | Full retest against the previously selected controls |
| `code/check_correctness.py` | Synthetic derivative, factorization and POT checks |
| `code/verify_record.py` | Read-only audit of hashes, counts, pairing and summaries |
| `code/run_reproduction.py` | Run numerical checks or benchmarks in a new directory |
| `results/raw.csv`, `raw.jsonl` | 1,728 initial timing records |
| `results/revised_raw.csv`, `revised_raw.jsonl` | 576 revised timing records |
| `results/configuration_summary.csv` | All 96 initial configurations and all control times |
| `results/revised_configuration_summary.csv` | All 96 revised configurations, including losses |
| `results/checks.json`, `correctness.json` | Original all-scenario and synthetic checks |
| `results/revised_summary.json` | Revised timing and numerical checks per configuration |
| `results/input_manifest.json`, `environment.json` | Input hashes, provenance and recorded runtime |
| `development_records/` | Smoke tests, interrupted attempts and development diagnostics |
| `figures/Figure_SU1.*` | Final figure in PNG, SVG and PDF formats |
| `document_source/` | Editable Markdown, reference DOCX and authoring script provenance |
| `SHA256SUMS.json` | Hash of every delivered file except this manifest itself |

The two HCC samples are from the same patient. Lung sample condition codes
are preserved. Metadata marked “frozen held-out test” describe the original
balanced-study split; these inputs were used for development of this UOT extension.
They do not constitute an independent UOT holdout set.

## Inspect the deposited record

Use Python 3.12 and the recorded requirements for the closest match:

```sh
python -m pip install -r requirements.txt
python code/verify_record.py
```

The verifier does not rerun solvers or overwrite the original timing record.
The six input hashes are checked against `results/input_manifest.json`.

## Reproduce in a separate directory

Run from this archive's root. The output directory must not already exist and
must be outside the deposit. This preserves original timings and checks.

```sh
# Synthetic correctness checks only
python code/run_reproduction.py --output ../uot_correctness_run --mode check

# Synthetic checks and a two-configuration initial smoke benchmark
python code/run_reproduction.py --output ../uot_smoke_run --mode smoke

# Both complete grids, followed by record verification
python code/run_reproduction.py --output ../uot_full_run --mode full
```

The full run performs 2,304 timed solver calls; each solver has a 60-second
budget and can therefore take substantially longer than smoke mode. Methods
are batched, baseline-warm-started, float64, one pinned CPU and one BLAS thread
where supported. New timings will depend on hardware and runtime. The numeric
scripts refuse to overwrite existing raw timing files.

The unbalanced objective, score normalization and factorization are specified
in `DERIVATION.md`. The main speed grid uses epsilon 0.05, symmetric marginal
penalties, 384 references, 307–500 queries, and 16/64 random scenarios. Radii
are centered log-proportion L2 distances, not total-variation percentages.
Only first-order prediction is used. No unbalanced directed search, ranking,
R interface, new disease-mechanism result or universal speed claim is included.

## Data and software provenance

Prepared inputs originate from the manuscript's archived `OT_Code_Data.zip`,
`matched_tv_20261118/prepared`, for GSE149614 (HCC) and GSE135893 (lung).
Preprocessing and reference construction are described in the original study;
these files reproduce the added solver benchmark, not the entire preprocessing
workflow. Archived labels are reference labels, not newly established biological
truth. The input files retain their original provenance and terms.

The source algorithms are cited in the addendum. The translation-invariant
control is a batched implementation of Séjourné et al. (AISTATS 2022), Algorithm 2.
POT 0.9.7.post1 provides independent high-accuracy checks. Its MIT license is
included as `POT_LICENSE.txt`. Repository code follows the root MIT license.
NumPy, SciPy, pandas, Matplotlib and other dependencies retain their own licenses.

The authoring script in `document_source/` records the document build and assumes
the original workspace layout. For portable text editing, use its Markdown and
reference DOCX; the numerical reproduction commands above do not need document
rendering tools. The current released package interface remains balanced OT.
