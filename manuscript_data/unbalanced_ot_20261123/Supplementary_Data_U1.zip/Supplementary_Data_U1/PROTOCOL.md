# Frozen UOT feasibility pilot — 2026-11-23

Written before performance runs. This is a new exploratory extension, not a change to the submitted paper or a claim of new general-purpose UOT theory.

## Question and problem
Does baseline implicit prediction plus a reused Schur factorization accelerate repeated reference-composition solves in fully KL-unbalanced entropic OT?

Objective: `<C,G> + eps KL(G | a b^T) + rho_a KL(G1 | a) + rho_b KL(G^T1 | b)`, with generalized KL, strictly positive a,b and fixed C. Define tau = rho/(rho+eps). Both marginals are relaxed; the submitted balanced marginal residual is NOT a valid stopping test here.

## Inputs, chosen without inspecting performance
Use the first two files with at least 300 query cells, in lexicographic fold/sample order, in each of the archived HCC_Myeloid, IPF_Epithelial and IPF_Mesenchymal tasks. Each has 384 reference cells. These are computational cases, not six independent biological cohorts; the HCC normal/tumor samples share a donor.

Use archived costs, labels and baseline b unchanged. Draw 64 centered, unit-L2 Gaussian class log-proportion directions with seed 20261123. Two radii: 0.10 (local) and 0.50 (stress). Normalize perturbed class probabilities, preserve within-class weights. Use the first 16 or all 64 scenarios. No query labels used for selection or optimization.

Main grid: eps 0.05; symmetric tau_a=tau_b in {0.5, 0.9, 0.99, 0.999}; radii {0.10,0.50}; scenario counts {16,64}; six files = 96 configurations. tau 0.5 is strongly relaxed, tau 0.999 is nearly balanced. The corresponding rho is eps*tau/(1-tau). These are a parameter sweep, not optimized biological settings.

## Solvers and fairness
1. Batched baseline-warm-start unbalanced Sinkhorn.
2. Batched baseline-warm-start unbalanced Anderson-accelerated Sinkhorn, memory 2, normalized Gram ridge 0.01 (AA2, matching the original package's convention).
3. First-order implicit prediction in log reference weights plus frozen Schur correction, safeguarded by residual backtracking and AA2 fallback; fallback to plain Sinkhorn if necessary. This pilot does NOT implement second-order UOT prediction.

All use the SAME KL-product objective, kernel, initial baseline, float64, CPU, single BLAS thread, class-score readout and convergence test. For `y=log v` after absorbing a,b into scalings, `x=log a - tau_a log(K exp y)` and `T(y)=log b - tau_b log(K^T exp x)`. Stop only when max absolute `T(y)-y` across reference cells is at most 1e-8 for every scenario. Verify returned plans independently against POT's single-target KL solver at tighter tolerance, not POT's multi-histogram loss-only path.

Shared method: factor at baseline, choose target Schur or equivalent source Woodbury factor according to the smaller dimension; maximum 40 chord iterations, 12 backtracks, log step <=4. All setup, derivative prediction, line searches, fallbacks and class-score readouts count in audit timing. Common input/kernel construction and baseline solve are timed separately. Report both audit-only and baseline-inclusive speedups. A 60-second solver budget per method/configuration; failures/timeouts retained. Native memory footprint is not a claimed benefit.

Three cyclic method-order timing repeats in one process, CPU affinity fixed where permitted. Repeat timing observations are not biological replication. Use median times per configuration, and compare against the faster of plain/AA2, not only the weaker method. Record raw times, iterations, residuals, fallback counts, score differences and label differences. Do not drop slow shared runs. Timing can be machine-dependent; this is feasibility evidence, not a publication-grade full benchmark.

## Correctness gates before timing
Check analytic Schur/Jacobian by finite differences, first-order predictor derivative, source/target linear solves, and several small random problems against independent high-accuracy POT. For real inputs, validate at least the first scenario of every configuration, and compare all scenarios across the three methods. Row-normalized transported class masses define scores; because source masses may vary, dividing by original a does not give normalized probabilities. Report mass change separately.

## Interpretation
Numerically equal outputs establish acceleration correctness only. A label switch is not proof of error, and fewer switches under relaxed constraints is not proof of better annotation. Do not import the balanced manuscript's 2.55x estimate into this experiment.

## Pre-main-run amendment after two smoke configurations

The near-balanced smoke case exposed slow convergence of the global scaling mode in ordinary UOT Sinkhorn; plain AA2 did not remove it. Comparing only to these methods would overstate the practical benefit. BEFORE the main 96-configuration run, add three stronger batched baselines: scalar-mode-centered Sinkhorn, scalar-mode-centered AA2, and the published translation-invariant Sinkhorn (Sejourne et al., AISTATS 2022), adapted from POT 0.9.7 while preserving the KL-product objective. Choose the fastest of ALL FIVE controls for the primary speedup. The centered controls analytically eliminate the constant mode using T(y+s)=T(y)+tau_a*tau_b*s, with s=mean(T(y)-y)/(1-tau_a*tau_b). They are diagnostic strong controls, not claimed novel algorithms. TI uses five-iteration check intervals and the same final residual. Retain original smoke outputs; do not include smoke timings in the main summary. Six methods x three repeats x 96 configurations = 1,728 timed runs.

Implementation validation note: an initial main-process launch was interrupted while the newly added TI control was still undergoing validation. The direct POT-source adaptation failed the asymmetric-penalty check. The first TI soft-min was corrected to use `exp(-g/rho_b)`, consistent with Algorithm 2 of the original paper. All pre-validation partial timings are retained in `results/prevalidation_aborted` and excluded in full, not selectively. The final main run starts from scratch after all correctness gates pass. The TI control is therefore a paper-based batched implementation, not an unmodified POT timing.

The final TI adapter is explicitly restricted to symmetric penalties, as in paper Algorithm 2 and the entire main performance grid, and centers its free representation shift before each update. Its four symmetric correctness checks pass against independent POT standard Sinkhorn. The additional asymmetric correctness test applies to the shared method and centered controls only; no asymmetric TI performance claim is made. Main performance does not establish shared-method asymmetric speedup either.

Common-baseline workflow correction: the global scaling issue also affected the single common baseline fit (2.22 seconds for the near-balanced smoke example). Use the validated scalar-mode-centered AA2 to compute that common fit for EVERY method at tolerance 1e-12. Restart all main timings, retaining the interrupted development run under `results/baseline_workflow_development`. This prevents a known avoidable initialization bottleneck from dominating end-to-end timing. Audit controls, shared method, input selection, parameter grid, stopping tolerance and repeat counts are unchanged. These are development amendments, not a prospectively registered confirmatory study.

Cold-start safeguard: the unconstrained centering shift can overflow from a poor near-balanced cold start. Cap it to +/-4 log units per step. The exact centering formula is applied when inside that bound; the target fixed point is unchanged. Retain that development failure and its preceding timings under `results/cold_start_development`; rerun the complete grid. Verify all six tau=0.999 cold starts and all numerical gates before the final run. No failures observed in development are erased from the archive.
