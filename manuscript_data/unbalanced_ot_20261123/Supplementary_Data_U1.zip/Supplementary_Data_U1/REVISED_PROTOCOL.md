# Post-hoc fallback revision and full-grid retest

The original 96-configuration benchmark is preserved, including substantial
slowdowns in some epithelial cases. During that run, the original shared
fallback was found to retain the scalar slow mode already removed in the
strong centered controls. The revised implementation changes ONLY the fallback
calls to enable `recenter=True`; the predictor, factorization, 40-iteration
cap, line search, tolerance, data, grid and scenarios are unchanged.

After the original run finishes, retest ALL 96 configurations, not only those
that improve. For each configuration, select the fastest successful control
from its original three-repeat medians among all five controls. Measure that
fixed control and the revised shared method again, in alternating order, with
three repeats, the same CPU affinity and single BLAS thread. This adds 576
timings. Both methods include class-score readout. Common initialization is
timed separately using centered AA2.

Check all revised scenario scores and labels against the paired control;
check the first scenario of each case/tau/radius independently with POT,
48 distinct endpoints. Report every configuration and range, including losses.
Retain the original benchmark as a separate stage. A new median is not an
independent confirmation: these are the same development inputs, and the
revision was motivated by observed failures. The main control choices come
from the original run; small timing-order differences may change which
control would win a new five-way comparison.

Report the two originally problematic TILD006, tau=.999, radius=.5, B16/B64
cases to diagnose the fallback effect, with original and revised speed ratios.
Do not use them alone to summarize the whole grid. No new biological accuracy
claim, general UOT speed claim or memory benefit is made.
