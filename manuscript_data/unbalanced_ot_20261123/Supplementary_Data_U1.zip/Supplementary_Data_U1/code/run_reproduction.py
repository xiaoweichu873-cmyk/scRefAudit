"""Run the archived numerical methods in a new directory, preserving the deposit."""
from pathlib import Path
import argparse, shutil, subprocess, sys, json

BASE=Path(__file__).resolve().parents[1]

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output',required=True,help='A NEW directory outside the deposited record')
    p.add_argument('--mode',choices=['check','smoke','full'],default='check')
    args=p.parse_args()
    dest=Path(args.output).expanduser().resolve()
    if dest==BASE or BASE in dest.parents:raise ValueError('Use a directory outside the deposited record')
    dest.mkdir(parents=True,exist_ok=False)
    (dest/'results').mkdir()
    shutil.copytree(BASE/'code',dest/'code',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    shutil.copytree(BASE/'selected_inputs',dest/'selected_inputs')
    for name in ['requirements.txt','PROTOCOL.md','REVISED_PROTOCOL.md','DERIVATION.md']:
        shutil.copy2(BASE/name,dest/name)
    def run(script,*opts):
        subprocess.run([sys.executable,str(dest/'code'/script),*opts],check=True,cwd=dest)
    run('check_correctness.py')
    if args.mode=='smoke':run('benchmark.py','--smoke')
    if args.mode=='full':
        run('benchmark.py')
        run('benchmark_revised.py')
        run('verify_record.py')
    print(json.dumps({'output':str(dest),'mode':args.mode,'status':'completed'}))

if __name__=='__main__':main()
