"""Exploratory KL-product UOT with a shared reduced Hessian.

All scalings absorb the product measure a*b. No balanced-OT gauge shift is
permitted: the finite marginal penalties fix the gauge. See DERIVATION.md.
"""
import time
import numpy as np
from scipy.linalg import cho_factor, cho_solve


class Problem:
    def __init__(self, cost, a, eps, tau_a, tau_b):
        self.C = np.asarray(cost, dtype=float)
        self.a = np.asarray(a, dtype=float)
        self.eps, self.ta, self.tb = eps, tau_a, tau_b
        self.K = np.exp(-self.C / eps)
        self.la = np.log(self.a)[:, None]
        if np.any(self.K == 0):
            raise ValueError('This pilot requires an explicitly positive kernel')

    def evaluate(self, y, lb):
        v = np.exp(y)
        kv = self.K @ v
        x = self.la - self.ta * np.log(kv)
        u = np.exp(x)
        ktu = self.K.T @ u
        T = lb - self.tb * np.log(ktu)
        R = T - y
        err = np.max(np.abs(R), axis=0)
        return T, err, u, v, kv, ktu

    def score(self, y, labels):
        # u cancels from row-normalized class probabilities.
        v = np.exp(y)
        m, B = v.shape
        Y = np.eye(int(labels.max()) + 1)[labels]
        rhs = (v[:, :, None] * Y[:, None, :]).reshape(m, -1)
        masses = (self.K @ rhs).reshape(len(self.a), B, Y.shape[1])
        return masses / masses.sum(axis=2, keepdims=True)

    def plan(self, y, b):
        _, err, u, v, _, _ = self.evaluate(y[:, None], np.log(b)[:, None])
        return u[:, 0, None] * self.K * v[:, 0][None, :], float(err[0])


def solve_sinkhorn(p, bs, y0, memory=0, tol=1e-8, maxiter=100000,
                   budget=60, deadline=None, recenter=False):
    deadline = time.perf_counter() + budget if deadline is None else deadline
    lb = np.log(bs)
    y = np.array(y0, copy=True)
    B = bs.shape[1]
    active = np.arange(B)
    out = np.empty_like(y)
    iterations = np.zeros(B, dtype=int)
    residual = np.full(B, np.inf)
    hx, hf = [], []
    for it in range(maxiter + 1):
        if it % 20 == 0 and time.perf_counter() > deadline:
            raise TimeoutError('Sinkhorn/AA2 budget exceeded')
        T, err, *_ = p.evaluate(y, lb[:, active])
        if recenter:
            # Exact removal of the scalar slow mode using homogeneity:
            # T(y+s*1) = T(y)+tau_a*tau_b*s*1.
            shift = (T-y).mean(axis=0)/(1-p.ta*p.tb)
            # A cold, nearly balanced start can propose thousands of log
            # units before its shape is fitted. Limit the scalar step.
            shift = np.clip(shift,-4.,4.)
            y = y+shift; T = T+p.ta*p.tb*shift
            err = np.max(np.abs(T-y),axis=0)
        if not np.isfinite(err).all():
            raise FloatingPointError('nonfinite Sinkhorn/AA2 residual')
        done = err <= tol
        if done.any():
            ids = active[done]
            out[:, ids] = y[:, done]
            iterations[ids] = it
            residual[ids] = err[done]
            keep = ~done
            active, y, T = active[keep], y[:, keep], T[:, keep]
            hx, hf = [x[:, keep] for x in hx], [x[:, keep] for x in hf]
            if not len(active):
                return out, dict(iterations=iterations, residual=residual,
                                 fallback_count=0)
        if memory:
            hx.append(y.copy()); hf.append(T.copy())
            hx, hf = hx[-memory:], hf[-memory:]
            if len(hx) == memory:
                X, F = np.stack(hx, axis=2), np.stack(hf, axis=2)
                H = F-X
                gram = np.einsum('mbk,mbl->bkl', H, H)
                norm = np.maximum(np.linalg.norm(gram, axis=(1, 2)), 1e-300)
                co = np.linalg.solve(gram/norm[:, None, None] +
                                     .01*np.eye(memory)[None],
                                     np.ones((len(active), memory, 1)))[..., 0]
                co /= co.sum(axis=1, keepdims=True)
                candidate = np.einsum('mbk,bk->mb', F, co)
                # Bound an extrapolation without changing the fixed point.
                step = candidate-y
                scale = np.minimum(1., 4./np.maximum(np.max(np.abs(step), axis=0), 1e-300))
                y = y + step*scale
            else:
                y = T
        else:
            y = T
    raise RuntimeError('Sinkhorn/AA2 did not converge')


def solve_translation_invariant(p, bs, y0, tol=1e-8, budget=60):
    """Batched KL-product adaptation of POT 0.9.7 TI-Sinkhorn.

    Based on Sejourne, Vialard & Peyre (AISTATS 2022). Scalar updates follow
    ot.unbalanced.sinkhorn_unbalanced_translation_invariant. Unlike POT's
    multi-histogram loss path, retains a*b regularization for every scenario.
    """
    from scipy.special import logsumexp
    if p.ta != p.tb:
        raise ValueError('This pilot implements paper Algorithm 2 for symmetric penalties only')
    deadline=time.perf_counter()+budget
    ra=(1-p.ta)/p.ta; rb=(1-p.tb)/p.tb
    rhoa=p.eps/ra;rhob=p.eps/rb
    kr1=rhoa*rhoa/((p.eps+rhoa)*(rhoa+rhob))
    kr2=rhob*rhob/((p.eps+rhob)*(rhoa+rhob))
    xi1=rhob/(p.eps+rhoa+rhob);xi2=rhoa/(p.eps+rhoa+rhob)
    fi12=rhoa*rhob/(rhoa+rhob)
    lb=np.log(bs);la=p.la
    lv=y0-lb
    active=np.arange(bs.shape[1]);out=np.empty_like(bs)
    iterations=np.zeros(bs.shape[1],int);residual=np.full(bs.shape[1],np.inf)
    for it in range(1,100001):
        # TI potentials have a free representation shift. Keep it bounded;
        # the final lambda restores the unique physical UOT potentials.
        lv-=lv.mean(axis=0,keepdims=True)
        if it%20==0 and time.perf_counter()>deadline:raise TimeoutError('TI Sinkhorn budget exceeded')
        lba=lb[:,active]
        # The KL soft-min in Algorithm 2 has exp(-g/rho), not exp(+g/rho).
        lu_hat=-p.ta*np.log(p.K@np.exp(lba+lv))+kr2*logsumexp(lba-rb*lv,axis=0)
        lu=lu_hat-xi1*logsumexp(la-ra*lu_hat,axis=0)
        lv_hat=-p.tb*np.log(p.K.T@np.exp(la+lu))+kr1*logsumexp(la-ra*lu,axis=0)
        lv=lv_hat-xi2*logsumexp(lba-rb*lv_hat,axis=0)
        if it%5==0:
            lt=(logsumexp(la-ra*lu,axis=0)-logsumexp(lba-rb*lv,axis=0))*fi12/p.eps
            y=lba+lv-lt
            err=p.evaluate(y,lba)[1]
            if not np.isfinite(err).all():raise FloatingPointError('TI nonfinite residual')
            done=err<=tol
            if done.any():
                ids=active[done];out[:,ids]=y[:,done];iterations[ids]=it;residual[ids]=err[done]
                keep=~done;active=active[keep];lv=lv[:,keep]
                if not len(active):return out,dict(iterations=iterations,residual=residual,fallback_count=0)
    raise RuntimeError('TI Sinkhorn did not converge')


class SharedFactor:
    def __init__(self, p, b0, y0, labels, side='auto'):
        G, error = p.plan(y0, b0)
        if error > 1e-10:
            raise ValueError('Baseline is not sufficiently converged')
        self.r = G.sum(axis=1)
        self.c = G.sum(axis=0)
        self.G, self.y0, self.b0 = G, y0, b0
        n, m = G.shape
        self.side = ('source' if n < m else 'target') if side == 'auto' else side
        self.db = self.c/p.tb
        if self.side == 'target':
            H = np.diag(self.db) - p.ta*(G.T/self.r) @ G
        else:
            H = np.diag(self.r/p.ta) - (G/self.db) @ G.T
        self.chol = cho_factor(H, lower=True, check_finite=False)
        self.factor_dim = len(H)
        Y = np.eye(int(labels.max())+1)[labels]
        # Derivative with respect to class log probabilities. The caller uses
        # actual normalized log-probability differences, including their shift.
        self.jac = self.solve(self.db[:, None]*Y)

    def solve(self, rhs):
        if self.side == 'target':
            return cho_solve(self.chol, rhs, check_finite=False)
        base = rhs/self.db[:, None]
        temp = cho_solve(self.chol, self.G @ base, check_finite=False)
        return base + (self.G.T @ temp)/self.db[:, None]


def solve_shared(p, bs, b0, y0, labels, tol=1e-8, budget=60):
    start = time.perf_counter(); deadline = start+budget
    factor = SharedFactor(p, b0, y0, labels)
    prep_s = time.perf_counter()-start
    classes = int(labels.max())+1
    # Every b changes only by its class multiplier.
    class_dlog = np.vstack([np.log(bs[np.flatnonzero(labels == k)[0]])-
                             np.log(b0[np.flatnonzero(labels == k)[0]])
                             for k in range(classes)])
    y = y0[:, None] + factor.jac @ class_dlog
    B = bs.shape[1]; lb = np.log(bs)
    active = np.arange(B); out = np.empty_like(bs)
    iterations = np.zeros(B, int); residual = np.full(B, np.inf)
    fallback = []; backtracks = np.zeros(B, int); evaluations = np.zeros(B, int)
    T, err, u, v, kv, ktu = p.evaluate(y, lb)
    evaluations += 1
    for it in range(41):
        if time.perf_counter() > deadline:
            raise TimeoutError('Shared method budget exceeded')
        done = err <= tol
        if done.any():
            ids = active[done]; out[:, ids] = y[:, done]
            iterations[ids] = it; residual[ids] = err[done]
            keep = ~done; active = active[keep]
            y, T, err, u, v, kv, ktu = [z[:, keep] if z.ndim == 2 else z[keep]
                                      for z in (y, T, err, u, v, kv, ktu)]
        if not len(active) or it == 40:
            break
        c = v*ktu
        # F = c-s, and log(s/c) = (T-y)/tau_b. expm1 avoids cancellation.
        rhs = c*np.expm1((T-y)/p.tb)
        dy = factor.solve(rhs)
        step = np.minimum(1., 4./np.maximum(np.max(np.abs(dy), axis=0), 1e-300))
        good = np.zeros(len(active), bool)
        ny, nT, ne, nu, nv, nkv, nktu = [z.copy() for z in (y,T,err,u,v,kv,ktu)]
        for bt in range(12):
            ix = np.flatnonzero(~good)
            if not len(ix):
                break
            trial = y[:, ix]+dy[:, ix]*step[ix]
            zT, ze, zu, zv, zkv, zktu = p.evaluate(trial, lb[:, active[ix]])
            evaluations[active[ix]] += 1
            accept = np.isfinite(ze) & (ze <= err[ix]*(1-1e-4*step[ix]))
            acc = ix[accept]; good[acc] = True
            for dest, src in zip((ny,nT,nu,nv,nkv,nktu), (trial,zT,zu,zv,zkv,zktu)):
                dest[:,acc] = src[:,accept]
            ne[acc] = ze[accept]
            rej = ix[~accept]; step[rej] *= .5; backtracks[active[rej]] += 1
        if not good.all():
            ix = np.flatnonzero(~good); ids = active[ix]
            try:
                result, info = solve_sinkhorn(p, bs[:,ids], y[:,ix], memory=2, tol=tol, deadline=deadline)
            except (FloatingPointError, RuntimeError):
                result, info = solve_sinkhorn(p, bs[:,ids], y[:,ix], memory=0, tol=tol, deadline=deadline)
            out[:,ids] = result; iterations[ids] = it+info['iterations']
            residual[ids] = info['residual']; fallback.extend(ids.tolist())
            active = active[good]
            ny,nT,ne,nu,nv,nkv,nktu = [z[:,good] if z.ndim == 2 else z[good]
                                     for z in (ny,nT,ne,nu,nv,nkv,nktu)]
        y,T,err,u,v,kv,ktu = ny,nT,ne,nu,nv,nkv,nktu
    if len(active):
        result, info = solve_sinkhorn(p, bs[:,active], y, memory=2, tol=tol, deadline=deadline)
        out[:,active] = result; iterations[active] = 40+info['iterations']
        residual[active] = info['residual']; fallback.extend(active.tolist())
    return out, dict(iterations=iterations, residual=residual,
                     fallback_count=len(fallback), fallback_indices=fallback,
                     preparation_seconds=prep_s, factor_dim=factor.factor_dim,
                     factor_side=factor.side, backtracks=backtracks, evaluations=evaluations)
