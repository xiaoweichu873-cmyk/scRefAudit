"""Full-grid post-hoc retest of centered fallback versus the original winner.

Selection of control per configuration uses ALL original three-repeat timings,
not the retest. Every one of the 96 configurations is rerun, including losses.
No other shared-method hyperparameter changes. These are development data,
not a new held-out validation set.
"""
import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
try:os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
except (AttributeError,OSError):pass
import json,time
from pathlib import Path
import numpy as np,pandas as pd
from uot_core import Problem,solve_sinkhorn,solve_translation_invariant
from shared_centered_fallback import solve_shared
from benchmark import make_bs,selected_inputs
from check_correctness import pot_reference
BASE=Path(__file__).resolve().parents[1]

def run():
    original=pd.read_csv(BASE/'results/raw.csv')
    if len(original)!=1728:raise ValueError('Original grid must finish first')
    good=original[original.status=='ok']
    med=good.groupby(['config_id','method']).audit_seconds.agg(['median','count']).reset_index()
    med=med[(med['count']==3)&(med.method!='shared')]
    winners=med.loc[med.groupby('config_id')['median'].idxmin()].set_index('config_id').method.to_dict()
    path=BASE/'results/revised_raw.jsonl'
    if path.exists():raise ValueError('Will not overwrite revised timings')
    rows=[];summaries=[];seq=0
    for f in selected_inputs():
        z=np.load(f);C=z['cost'];b0=z['b'];_,labels=np.unique(z['reference_labels'],return_inverse=True)
        for tau in [.5,.9,.99,.999]:
            t=time.perf_counter();p=Problem(C,np.full(len(C),1/len(C)),.05,tau,tau);kernel_s=time.perf_counter()-t
            t=time.perf_counter();y0=solve_sinkhorn(p,b0[:,None],np.log(b0)[:,None],memory=2,recenter=True,tol=1e-12)[0][:,0];base_s=time.perf_counter()-t
            for radius in [.1,.5]:
                pot_cache=None
                for B in [16,64]:
                    cid=f'{f.stem}|{tau}|{radius}|{B}';best=winners[cid]
                    bs=make_bs(b0,labels,radius,B);probs={};sols={};infos={}
                    cfg=dict(case=f.stem,tau=tau,radius=radius,scenarios=B,config_id=cid,control=best,n=len(C),m=C.shape[1])
                    for rep in range(3):
                        order=['control','revised'] if (seq+rep)%2==0 else ['revised','control']
                        for method in order:
                            start=time.perf_counter()
                            if method=='revised':y,info=solve_shared(p,bs,b0,y0,labels)
                            elif best=='ti_sinkhorn':y,info=solve_translation_invariant(p,bs,np.repeat(y0[:,None],B,axis=1))
                            else:y,info=solve_sinkhorn(p,bs,np.repeat(y0[:,None],B,axis=1),memory=2 if 'aa2' in best else 0,recenter=best.startswith('centered'))
                            prob=p.score(y,labels);elapsed=time.perf_counter()-start
                            if rep==0:probs[method]=prob;sols[method]=y;infos[method]=info
                            row=dict(**cfg,repeat=rep,method=method,audit_seconds=elapsed,max_residual=float(info['residual'].max()),fallback_count=int(info['fallback_count']),preparation_seconds=float(info.get('preparation_seconds',0)),kernel_seconds=kernel_s,baseline_seconds=base_s)
                            rows.append(row)
                            with path.open('a') as handle:handle.write(json.dumps(row)+'\n')
                    if pot_cache is None:pot_cache=pot_reference(p,bs[:,0])
                    Gp,er=pot_cache;Gs,_=p.plan(sols['revised'][:,0],bs[:,0])
                    Y=np.eye(int(labels.max())+1)[labels];pp=Gp@Y/Gp.sum(1)[:,None];ps=Gs@Y/Gs.sum(1)[:,None]
                    mt={m:float(np.median([r['audit_seconds'] for r in rows[-6:] if r['method']==m])) for m in ['control','revised']}
                    sh=dict(**cfg,control_seconds=mt['control'],revised_seconds=mt['revised'],speedup=mt['control']/mt['revised'],speedup_with_initialization=(mt['control']+base_s+kernel_s)/(mt['revised']+base_s+kernel_s),preparation_seconds=float(np.median([r['preparation_seconds'] for r in rows[-6:] if r['method']=='revised'])),baseline_seconds=base_s,kernel_seconds=kernel_s,all_score_maxabs=float(abs(probs['control']-probs['revised']).max()),all_label_disagreements=int(np.sum(probs['control'].argmax(2)!=probs['revised'].argmax(2))),pot_score_maxabs=float(abs(pp-ps).max()),pot_label_disagreements=int(np.sum(pp.argmax(1)!=ps.argmax(1))),fallback_count=int(infos['revised']['fallback_count']))
                    summaries.append(sh);seq+=1
                    (BASE/'results/revised_summary.json').write_text(json.dumps(summaries,indent=2))
                    print(json.dumps(dict(config=seq,case=f.stem,tau=tau,radius=radius,B=B,speedup=sh['speedup'],times=mt)),flush=True)
    pd.DataFrame(rows).to_csv(BASE/'results/revised_raw.csv',index=False)
    pd.DataFrame(summaries).to_csv(BASE/'results/revised_configuration_summary.csv',index=False)

if __name__=='__main__':run()
