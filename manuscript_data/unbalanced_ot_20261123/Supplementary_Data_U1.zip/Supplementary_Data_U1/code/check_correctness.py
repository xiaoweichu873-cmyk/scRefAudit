import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
os.environ['MKL_NUM_THREADS']='1'
import json
from pathlib import Path
import numpy as np
import ot
from uot_core import Problem, SharedFactor, solve_sinkhorn, solve_shared, solve_translation_invariant


def pot_reference(p,b,tol=1e-13):
    rho=(p.eps*p.ta/(1-p.ta),p.eps*p.tb/(1-p.tb))
    G, log = ot.unbalanced.sinkhorn_unbalanced(
        p.a,b,p.C,p.eps,rho,reg_type='kl',method='sinkhorn',
        numItermax=200000,stopThr=tol,log=True)
    y=log['logv']+np.log(b)
    e=float(p.evaluate(y[:,None],np.log(b)[:,None])[1][0])
    if e>1e-10: raise AssertionError(('POT residual',e))
    return G,e


def run():
    rng=np.random.default_rng(7193)
    records=[]
    for ta,tb in [(.5,.5),(.9,.9),(.99,.99),(.999,.999),(.9,.99)]:
        n,m,q=17,23,4
        C=rng.uniform(0,1,(n,m)); a=rng.dirichlet(np.ones(n))
        labels=np.arange(m)%q; b0=rng.dirichlet(np.ones(m))
        p=Problem(C,a,.1,ta,tb)
        y0,info=solve_sinkhorn(p,b0[:,None],np.log(b0)[:,None],memory=2,tol=1e-12)
        y0=y0[:,0];G,_=p.plan(y0,b0)
        Gpot,pe=pot_reference(p,b0)
        assert np.max(np.abs(G-Gpot))<1e-9
        target=SharedFactor(p,b0,y0,labels,side='target')
        source=SharedFactor(p,b0,y0,labels,side='source')
        rhs=rng.normal(size=(m,3))
        factor_error=np.max(np.abs(target.solve(rhs)-source.solve(rhs)))/max(1,np.max(np.abs(target.solve(rhs))))
        assert factor_error<1e-10
        def F(y,b):
            T,_,_,v,_,ktu=p.evaluate(y[:,None],np.log(b)[:,None])
            c=v*ktu
            return (-c*np.expm1((T-y[:,None])/tb))[:,0]
        d=rng.normal(size=m);h=1e-5
        fd=(F(y0+h*d,b0)-F(y0-h*d,b0))/(2*h)
        H=np.diag(G.sum(0)/tb)-ta*(G.T/G.sum(1))@G
        hessian_error=np.max(np.abs(fd-H@d))
        assert hessian_error<1e-8
        z=rng.normal(size=q); z-=z.mean()
        def b_at(t):
            b=b0*np.exp(t*z[labels]);return b/b.sum()
        yp=solve_sinkhorn(p,b_at(h)[:,None],y0[:,None],memory=2,tol=1e-13)[0][:,0]
        ym=solve_sinkhorn(p,b_at(-h)[:,None],y0[:,None],memory=2,tol=1e-13)[0][:,0]
        pred=target.jac@(z-np.sum(b0*z[labels]))
        derivative_error=np.max(np.abs((yp-ym)/(2*h)-pred))
        assert derivative_error<1e-5
        bs=np.column_stack([b_at(.1),b_at(.5),b_at(-.5)])
        yti=None
        if ta==tb:
            yti,ti=solve_translation_invariant(p,bs,np.repeat(y0[:,None],3,axis=1),tol=1e-10)
        yc,ci=solve_sinkhorn(p,bs,np.repeat(y0[:,None],3,axis=1),memory=2,recenter=True,tol=1e-10)
        ys,si=solve_shared(p,bs,b0,y0,labels,tol=1e-10)
        max_plan_diff=0
        max_ti_diff=0;max_centered_diff=0
        for j in range(3):
            Gs,_=p.plan(ys[:,j],bs[:,j]);Gp,_=pot_reference(p,bs[:,j])
            max_plan_diff=max(max_plan_diff,float(np.max(np.abs(Gs-Gp))))
            if yti is not None:max_ti_diff=max(max_ti_diff,float(abs(p.plan(yti[:,j],bs[:,j])[0]-Gp).max()))
            max_centered_diff=max(max_centered_diff,float(abs(p.plan(yc[:,j],bs[:,j])[0]-Gp).max()))
        assert max_plan_diff<1e-8
        assert max_ti_diff<1e-8 and max_centered_diff<1e-8
        records.append(dict(tau_a=ta,tau_b=tb,pot_plan_maxabs=float(np.max(np.abs(G-Gpot))),
                            factor_relative_error=float(factor_error),hessian_fd_maxabs=float(hessian_error),
                            predictor_fd_maxabs=float(derivative_error),shared_pot_maxabs=max_plan_diff,
                            shared_residual_max=float(si['residual'].max()),fallback_count=si['fallback_count'],ti_pot_maxabs=max_ti_diff if yti is not None else None,centered_aa2_pot_maxabs=max_centered_diff))
    path=Path(__file__).resolve().parents[1]/'results/correctness.json'
    path.write_text(json.dumps(records,indent=2))
    print(json.dumps(records,indent=2))

if __name__=='__main__':run()
