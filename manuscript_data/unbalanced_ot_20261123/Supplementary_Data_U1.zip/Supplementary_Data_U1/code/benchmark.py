import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
os.environ['MKL_NUM_THREADS']='1'
try:
    os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
except (AttributeError, OSError):pass
import time, json, hashlib, platform, shutil, argparse
from pathlib import Path
import numpy as np
import scipy, pandas as pd, ot
from threadpoolctl import threadpool_info
from uot_core import Problem, solve_sinkhorn, solve_shared, solve_translation_invariant
from check_correctness import pot_reference

BASE=Path(__file__).resolve().parents[1]
METHODS=['sinkhorn','aa2','centered_sinkhorn','centered_aa2','ti_sinkhorn','shared']

def selected_inputs():
    root=BASE/'original_archive/OT/06_Code_and_source_data/matched_tv_20261118/prepared'
    files=sorted((BASE/'selected_inputs').glob('*.npz'))
    if files:return files
    files=[]
    for task in ['HCC_Myeloid','IPF_Epithelial','IPF_Mesenchymal']:
        candidates=[]
        for f in sorted((root/task).glob('*/*.npz')):
            with np.load(f) as z:
                if len(z['cost'])>=300:candidates.append(f)
        for f in candidates[:2]:
            dest=BASE/'selected_inputs'/f'{task}__{f.parent.name}__{f.name}'
            shutil.copyfile(f,dest);files.append(dest)
    return files


def make_bs(b0,labels,radius,count):
    q=int(labels.max())+1
    rng=np.random.default_rng(20261123)
    d=rng.normal(size=(q,64));d-=d.mean(axis=0)
    d/=np.linalg.norm(d,axis=0)
    bs=b0[:,None]*np.exp(radius*d[labels,:count])
    return bs/bs.sum(axis=0)


def objective(p,G,b):
    from scipy.special import xlogy
    def kl(x,y):return float(np.sum(xlogy(x,x/y)-x+y))
    return float(np.sum(p.C*G))+p.eps*kl(G,p.a[:,None]*b[None,:])+p.eps*p.ta/(1-p.ta)*kl(G.sum(1),p.a)+p.eps*p.tb/(1-p.tb)*kl(G.sum(0),b)


def main(smoke=False):
    suffix='_smoke' if smoke else ''
    raw_path=BASE/f'results/raw{suffix}.jsonl'
    if raw_path.exists():raise RuntimeError('Refusing to overwrite a completed/partial run')
    env=dict(platform=platform.platform(),python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,POT=ot.__version__,threadpools=threadpool_info(),affinity=sorted(os.sched_getaffinity(0)),cpu_info=Path('/proc/cpuinfo').read_text().split('model name')[1].split('\n')[0].strip(': \t'))
    (BASE/f'results/environment{suffix}.json').write_text(json.dumps(env,indent=2))
    files=selected_inputs()
    taus=[.9,.999] if smoke else [.5,.9,.99,.999]
    radii=[.1] if smoke else [.1,.5]
    counts=[16] if smoke else [16,64]
    if smoke:files=files[:1]
    manifest=[]; baselines=[]; checks=[]; stats=[]; records=[]
    seq=0
    for f in files:
        with np.load(f) as z:
            C=z['cost'];b0=z['b'];classes,labels=np.unique(z['reference_labels'],return_inverse=True)
            metadata=json.loads(str(z['metadata']))
        manifest.append(dict(file=f.name,sha256=hashlib.sha256(f.read_bytes()).hexdigest(),shape=list(C.shape),metadata=metadata))
        a=np.full(len(C),1/len(C));Bcache={}
        for tau in taus:
            st=time.perf_counter();p=Problem(C,a,.05,tau,tau);kernel_s=time.perf_counter()-st
            st=time.perf_counter();y0,bi=solve_sinkhorn(p,b0[:,None],np.log(b0)[:,None],memory=2,recenter=True,tol=1e-12,budget=60);baseline_s=time.perf_counter()-st
            y0=y0[:,0];base_prob=p.score(y0[:,None],labels)[:,0,:]
            G0,_=p.plan(y0,b0)
            baselines.append(dict(case=f.stem,tau=tau,kernel_seconds=kernel_s,baseline_seconds=baseline_s,iterations=int(bi['iterations'][0]),residual=float(bi['residual'][0]),transported_mass=float(G0.sum()),source_l1_deviation=float(abs(G0.sum(1)-a).sum()),target_l1_deviation=float(abs(G0.sum(0)-b0).sum())))
            for radius in radii:
                for B in counts:
                    bs=make_bs(b0,labels,radius,B)
                    config=dict(case=f.stem,n=len(C),m=C.shape[1],eps=.05,tau=tau,radius=radius,scenarios=B)
                    config_id=f'{f.stem}|{tau}|{radius}|{B}'
                    solutions={};scores={};rep_times={}
                    for rep in range(1 if smoke else 3):
                        order=METHODS[(rep+seq)%len(METHODS):]+METHODS[:(rep+seq)%len(METHODS)]
                        for method in order:
                            row=dict(**config,config_id=config_id,repeat=rep,method=method,baseline_seconds=baseline_s,kernel_seconds=kernel_s,status='ok')
                            start=time.perf_counter()
                            try:
                                if method=='shared':
                                    y,info=solve_shared(p,bs,b0,y0,labels,tol=1e-8,budget=60)
                                elif method=='ti_sinkhorn':
                                    y,info=solve_translation_invariant(p,bs,np.repeat(y0[:,None],B,axis=1),tol=1e-8,budget=60)
                                else:
                                    y,info=solve_sinkhorn(p,bs,np.repeat(y0[:,None],B,axis=1),memory=2 if 'aa2' in method else 0,recenter=method.startswith('centered'),tol=1e-8,budget=60)
                                prob=p.score(y,labels)
                                elapsed=time.perf_counter()-start
                                row.update(audit_seconds=elapsed,total_seconds=elapsed+baseline_s+kernel_s,
                                           residual_max=float(info['residual'].max()),iterations_median=float(np.median(info['iterations'])),iterations_max=int(info['iterations'].max()),fallback_count=int(info['fallback_count']),preparation_seconds=float(info.get('preparation_seconds',0)),factor_dim=info.get('factor_dim'),factor_side=info.get('factor_side'),backtrack_total=int(np.sum(info.get('backtracks',0))))
                                if rep==0:solutions[method]=y;scores[method]=prob
                                rep_times.setdefault(method,[]).append(elapsed)
                            except Exception as e:
                                row.update(status=type(e).__name__,error=str(e),audit_seconds=time.perf_counter()-start)
                            records.append(row)
                            with raw_path.open('a') as handle:handle.write(json.dumps(row)+'\n')
                    check=dict(**config,config_id=config_id)
                    if len(scores)==len(METHODS):
                        check['all_scenarios_max_score_difference']=max(float(np.max(abs(scores['shared']-s))) for s in scores.values())
                        check['all_scenarios_label_disagreements']=sum(int(np.sum(scores['shared'].argmax(2)!=s.argmax(2))) for s in scores.values())
                        check['all_scenarios_shared_aa2_score_maxabs']=float(np.max(np.abs(scores['shared']-scores['aa2'])))
                        check['all_scenarios_shared_plain_score_maxabs']=float(np.max(np.abs(scores['shared']-scores['sinkhorn'])))
                        check['all_scenarios_shared_aa2_label_disagreements']=int(np.sum(scores['shared'].argmax(2)!=scores['aa2'].argmax(2)))
                        check['all_scenarios_shared_plain_label_disagreements']=int(np.sum(scores['shared'].argmax(2)!=scores['sinkhorn'].argmax(2)))
                        if radius not in Bcache:
                            Gp,er=pot_reference(p,bs[:,0]);Bcache[radius]=(Gp,er)
                        Gp,er=Bcache[radius]
                        # Bcache is cleared for every tau below.
                        Gs,er2=p.plan(solutions['shared'][:,0],bs[:,0])
                        Y=np.eye(len(classes))[labels]
                        ps=Gs@Y/Gs.sum(1)[:,None];pp=Gp@Y/Gp.sum(1)[:,None]
                        check.update(pot_residual=er,shared_residual=er2,pot_plan_maxabs=float(np.max(abs(Gs-Gp))),pot_plan_relative_l1=float(abs(Gs-Gp).sum()/Gp.sum()),pot_score_maxabs=float(abs(ps-pp).max()),pot_label_disagreements=int(np.sum(ps.argmax(1)!=pp.argmax(1))),objective_difference=float(objective(p,Gs,bs[:,0])-objective(p,Gp,bs[:,0])))
                        stats.append(dict(**config,any_switch_percent=float(100*np.mean(np.any(scores['shared'].argmax(2)!=base_prob.argmax(1)[:,None],axis=1))),mean_switch_percent=float(100*np.mean(scores['shared'].argmax(2)!=base_prob.argmax(1)[:,None])),median_tv=float(np.median(.5*abs(bs-b0[:,None]).sum(0)))))
                    checks.append(check)
                    seq+=1
                    summary={k:round(float(np.median(v)),5) for k,v in rep_times.items()}
                    print(json.dumps(dict(config=seq,case=f.stem,tau=tau,radius=radius,B=B,times=summary,ratio=(min(v for k,v in summary.items() if k!='shared')/summary['shared'] if len(summary)==len(METHODS) else None),score_error=check.get('pot_score_maxabs'))),flush=True)
                    for name,content in [('checks',checks),('baselines',baselines),('sensitivity',stats),('input_manifest',manifest)]:
                        (BASE/f'results/{name}{suffix}.json').write_text(json.dumps(content,indent=2))
            Bcache={}
    pd.DataFrame(records).to_csv(BASE/f'results/raw{suffix}.csv',index=False)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--smoke',action='store_true');args=parser.parse_args();main(args.smoke)
