"""Post-hoc diagnostic variant: only center the scalar mode in fallback.
Not the solver used in the original 96-configuration benchmark.
"""
import time
import numpy as np
from uot_core import SharedFactor, solve_sinkhorn

def solve_shared(p, bs, b0, y0, labels, tol=1e-8, budget=60):
    start = time.perf_counter(); deadline = start+budget
    factor = SharedFactor(p, b0, y0, labels)
    prep_s = time.perf_counter()-start
    classes = int(labels.max())+1
    # Every b changes only by its class multiplier.
    class_dlog = np.vstack([np.log(bs[np.flatnonzero(labels == k)[0]])-
                             np.log(b0[np.flatnonzero(labels == k)[0]])
                             for k in range(classes)])
    y = y0[:, None] + factor.jac @ class_dlog
    B = bs.shape[1]; lb = np.log(bs)
    active = np.arange(B); out = np.empty_like(bs)
    iterations = np.zeros(B, int); residual = np.full(B, np.inf)
    fallback = []; backtracks = np.zeros(B, int); evaluations = np.zeros(B, int)
    T, err, u, v, kv, ktu = p.evaluate(y, lb)
    evaluations += 1
    for it in range(41):
        if time.perf_counter() > deadline:
            raise TimeoutError('Shared method budget exceeded')
        done = err <= tol
        if done.any():
            ids = active[done]; out[:, ids] = y[:, done]
            iterations[ids] = it; residual[ids] = err[done]
            keep = ~done; active = active[keep]
            y, T, err, u, v, kv, ktu = [z[:, keep] if z.ndim == 2 else z[keep]
                                      for z in (y, T, err, u, v, kv, ktu)]
        if not len(active) or it == 40:
            break
        c = v*ktu
        # F = c-s, and log(s/c) = (T-y)/tau_b. expm1 avoids cancellation.
        rhs = c*np.expm1((T-y)/p.tb)
        dy = factor.solve(rhs)
        step = np.minimum(1., 4./np.maximum(np.max(np.abs(dy), axis=0), 1e-300))
        good = np.zeros(len(active), bool)
        ny, nT, ne, nu, nv, nkv, nktu = [z.copy() for z in (y,T,err,u,v,kv,ktu)]
        for bt in range(12):
            ix = np.flatnonzero(~good)
            if not len(ix):
                break
            trial = y[:, ix]+dy[:, ix]*step[ix]
            zT, ze, zu, zv, zkv, zktu = p.evaluate(trial, lb[:, active[ix]])
            evaluations[active[ix]] += 1
            accept = np.isfinite(ze) & (ze <= err[ix]*(1-1e-4*step[ix]))
            acc = ix[accept]; good[acc] = True
            for dest, src in zip((ny,nT,nu,nv,nkv,nktu), (trial,zT,zu,zv,zkv,zktu)):
                dest[:,acc] = src[:,accept]
            ne[acc] = ze[accept]
            rej = ix[~accept]; step[rej] *= .5; backtracks[active[rej]] += 1
        if not good.all():
            ix = np.flatnonzero(~good); ids = active[ix]
            try:
                result, info = solve_sinkhorn(p, bs[:,ids], y[:,ix], memory=2, recenter=True, tol=tol, deadline=deadline)
            except (FloatingPointError, RuntimeError):
                result, info = solve_sinkhorn(p, bs[:,ids], y[:,ix], memory=0, recenter=True, tol=tol, deadline=deadline)
            out[:,ids] = result; iterations[ids] = it+info['iterations']
            residual[ids] = info['residual']; fallback.extend(ids.tolist())
            active = active[good]
            ny,nT,ne,nu,nv,nkv,nktu = [z[:,good] if z.ndim == 2 else z[good]
                                     for z in (ny,nT,ne,nu,nv,nkv,nktu)]
        y,T,err,u,v,kv,ktu = ny,nT,ne,nu,nv,nkv,nktu
    if len(active):
        result, info = solve_sinkhorn(p, bs[:,active], y, memory=2, recenter=True, tol=tol, deadline=deadline)
        out[:,active] = result; iterations[active] = 40+info['iterations']
        residual[active] = info['residual']; fallback.extend(active.tolist())
    return out, dict(iterations=iterations, residual=residual,
                     fallback_count=len(fallback), fallback_indices=fallback,
                     preparation_seconds=prep_s, factor_dim=factor.factor_dim,
                     factor_side=factor.side, backtracks=backtracks, evaluations=evaluations)
