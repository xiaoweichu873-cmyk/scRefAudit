"""Check the deposited record without rerunning or changing timed experiments."""
from pathlib import Path
import hashlib, json
import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parents[1]

def verify():
    R=BASE/'results'
    for item in json.loads((R/'input_manifest.json').read_text()):
        f=BASE/'selected_inputs'/item['file']
        assert hashlib.sha256(f.read_bytes()).hexdigest()==item['sha256'], f
        with np.load(f) as z:assert list(z['cost'].shape)==item['shape']
    initial=pd.read_csv(R/'raw.csv')
    revised=pd.read_csv(R/'revised_raw.csv')
    final=pd.read_csv(R/'revised_configuration_summary.csv')
    assert len(initial)==1728 and len(revised)==576 and len(final)==96
    assert (initial.status=='ok').all()
    assert initial.groupby(['config_id','method']).size().eq(3).all()
    assert revised.groupby(['config_id','method']).size().eq(3).all()
    assert initial.config_id.nunique()==96 and revised.config_id.nunique()==96
    med=initial.groupby(['config_id','method']).audit_seconds.median().unstack()
    winners=med.drop(columns='shared').idxmin(axis=1)
    chosen=final.set_index('config_id').control
    assert (winners.sort_index()==chosen.sort_index()).all()
    fresh=revised.groupby(['config_id','method']).audit_seconds.median().unstack()
    check=final.set_index('config_id').loc[fresh.index]
    np.testing.assert_allclose(fresh.control,check.control_seconds,rtol=1e-12)
    np.testing.assert_allclose(fresh.revised,check.revised_seconds,rtol=1e-12)
    np.testing.assert_allclose(fresh.control/fresh.revised,check.speedup,rtol=1e-12)
    common=check.baseline_seconds+check.kernel_seconds
    np.testing.assert_allclose((fresh.control+common)/(fresh.revised+common),check.speedup_with_initialization,rtol=1e-12)
    assert final.all_label_disagreements.sum()==0 and final.pot_label_disagreements.sum()==0
    assert revised.max_residual.max()<=1e-8
    out={'configurations':len(final),'initial_timings':len(initial),'revised_timings':len(revised),
         'median_speedup':float(final.speedup.median()),
         'median_with_initialization':float(final.speedup_with_initialization.median()),
         'faster':int((final.speedup>1).sum()),'slower':int((final.speedup<1).sum()),
         'local_median':float(final.loc[final.radius==.1,'speedup'].median()),
         'stress_median':float(final.loc[final.radius==.5,'speedup'].median()),
         'all_score_maxabs':float(final.all_score_maxabs.max()),
         'all_label_disagreements':int(final.all_label_disagreements.sum()),
         'pot_score_maxabs':float(final.pot_score_maxabs.max()),
         'pot_label_disagreements':int(final.pot_label_disagreements.sum()),
         'fallback_scenarios':int(final.fallback_count.sum()),
         'scenario_count':int(final.scenarios.sum())}
    if (R/'revised_overall.json').exists():
        expected=json.loads((R/'revised_overall.json').read_text())
        for k,v in out.items():
            if k in expected:assert np.isclose(v,expected[k],rtol=1e-12,atol=1e-16),(k,v,expected[k])
    if (BASE/'SHA256SUMS.json').exists():
        for name,digest in json.loads((BASE/'SHA256SUMS.json').read_text()).items():
            assert hashlib.sha256((BASE/name).read_bytes()).hexdigest()==digest,name
    return out

if __name__=='__main__':print(json.dumps({'status':'passed',**verify()},indent=2))
