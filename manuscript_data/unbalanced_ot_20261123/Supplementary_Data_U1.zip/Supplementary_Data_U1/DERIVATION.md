# Shared-curvature extension to fully KL-unbalanced OT

This is an exploratory implementation of established implicit differentiation and modified-Newton ideas for a new objective. It is not a proof of a new general-purpose UOT algorithm or universal speed dominance.

## Objective and conventions

For positive a,b, minimize over G >= 0

\[
\langle C,G\rangle+\epsilon\operatorname{KL}(G\mid ab^T)
+\rho_a\operatorname{KL}(G\mathbf1\mid a)
+\rho_b\operatorname{KL}(G^T\mathbf1\mid b).
\]

Generalized KL includes `-x+y`. Let `tau_a=rho_a/(rho_a+eps)` and similarly for b. Unlike balanced OT, changing KL(G|ab^T) to negative entropy changes this problem. All controls and independent checks use the product-KL convention.

Absorb a,b into scalings: `G=diag(exp(x)) K diag(exp(y))`, `K=exp(-C/eps)`. Eliminating the source potential gives

\[
x(y)=\log a-\tau_a\log(K e^y),\quad
T(y;b)=\log b-\tau_b\log(K^T e^{x(y)}).
\]

The solution satisfies `T(y;b)-y=0`. This log fixed-point residual is the common stopping test; requiring original marginals to match would be WRONG for UOT. With y specified, the source stationarity equation is enforced exactly by elimination.

## Reduced Hessian

Write row and column transported masses as r=G1 and c=G^T1. Define

\[
s_j=b_j^{1/\tau_b}e^{-(1-\tau_b)y_j/\tau_b},\qquad F(y,b)=c-s.
\]

At a solved baseline, `s=c`, and

\[
H_0=\frac1{\tau_b}\operatorname{diag}(c_0)
-\tau_aG_0^T\operatorname{diag}(r_0)^{-1}G_0.
\]

Since `G^T diag(r)^-1 G <= diag(c)`, finite penalties give

\[
H_0\succeq(1/\tau_b-\tau_a)\operatorname{diag}(c_0)>0.
\]

Unlike balanced OT, a gauge-fixing rank-one term must NOT be added. Finite marginal penalties fix the physical gauge.

If m <= n, factor H0 directly. Otherwise use Woodbury with `D=diag(c0/tau_b)` and

\[
A=\operatorname{diag}(r_0)/\tau_a-G_0D^{-1}G_0^T,
\quad
H_0^{-1}R=D^{-1}R+D^{-1}G_0^TA^{-1}G_0D^{-1}R.
\]

This factors min(n,m) dimensions. Near tau=1 the problem can still be ill-conditioned; positivity alone is not a uniform performance guarantee.

## Prediction and correction

For class-membership matrix Y, reference log weights change by `d log b = Y d log p`, where p includes its normalization. Implicit differentiation yields

\[
\frac{dy}{d\log p}=H_0^{-1}\operatorname{diag}(c_0/\tau_b)Y.
\]

Compute this once, predict each scenario, then use a frozen-factor chord update. The residual RHS is evaluated accurately as

\[
s-c=c\odot\operatorname{expm1}((T(y;b)-y)/\tau_b).
\]

Apply `dy=H0^-1(s-c)`, backtrack for reduction of the log residual, and fall back to AA2 after failure/40 iterations. Setup, first derivatives, corrections and fallback are charged. This pilot uses FIRST-order prediction, whereas the submitted balanced method also has a second-order variant.

## Strong controls

Plain UOT Sinkhorn has a scalar mode with multiplier tau_a*tau_b. A baseline that ignores it can be extremely slow near balance. Use the homogeneity identity

\[
T(y+t\mathbf1)=T(y)+\tau_a\tau_b t\mathbf1
\]

to remove the mean residual by shifting y by `mean(T-y)/(1-tau_a*tau_b)`. For numerical safety the applied shift is limited to +/-4 log units; it is exact when that bound is inactive. Both centered Sinkhorn and centered AA2 are included as controls. This shifts the physical plan to solve its scalar mode; it is not a balanced-OT gauge normalization.

Also implement the symmetric-penalty KL-TI-Sinkhorn Algorithm 2 of Sejourne, Vialard and Peyre (2022), with its free REPRESENTATION shift centered and the unique physical potentials restored before the common residual check. This is distinct from the preceding mean-residual centering. The batched implementation is independently checked against POT standard single-target UOT; it is not an unmodified POT runtime comparison.

## Scores and limits

Scores are `G Y / (G 1)` rowwise. Dividing by original a would not yield normalized probabilities when source mass is relaxed. These scores are compared across solvers for the same objective, not declared biologically calibrated probabilities.

First-order accuracy, small finite-difference errors, and agreement with POT do not certify global convergence, label correctness, application to every UOT variant, or speed on another machine. This grid varies reference weights with fixed costs, positive weights, dense kernel, fixed epsilon and fixed symmetric marginal penalties. It does not test changing cost matrices, zero weights, unbalanced Gromov-Wasserstein, low-rank/online methods, GPUs, growth-rate parameterizations, or the entire moscot/Waddington-OT pipeline.

## Primary sources

- Sejourne, Vialard, Peyre. Faster Unbalanced Optimal Transport: Translation invariant Sinkhorn and 1-D Frank-Wolfe. AISTATS 2022. https://proceedings.mlr.press/v151/sejourne22a.html
- POT UOT API and objective conventions: https://pythonot.github.io/gen_modules/ot.unbalanced.html
- Original paper code inputs: user's archived `OT_Code_Data.zip`, prepared matched-TV inputs, with source hashes in results/input_manifest.json. The input data remain subject to their original provenance and terms.
